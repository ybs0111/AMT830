// Screen_Motor_Speed.cpp : implementation file
//

#include "stdafx.h"
#include "Handler.h"
#include "Screen_Motor_Speed.h"

#include "Variable.h"				// ���� ���� ���� Ŭ���� �߰�
// ******************************************************************************
// ��ȭ ���� Ŭ���� �߰�                                                         
// ******************************************************************************
#include "Dialog_Select.h"
#include "Dialog_Infor.h"
#include "Dialog_Message.h"

#include "Dialog_KeyPad.h"
// ******************************************************************************

#include "ComizoaPublic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScreen_Motor_Speed

IMPLEMENT_DYNCREATE(CScreen_Motor_Speed, CFormView)

CScreen_Motor_Speed::CScreen_Motor_Speed()
	: CFormView(CScreen_Motor_Speed::IDD)
{
	//{{AFX_DATA_INIT(CScreen_Motor_Speed)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	st_handler.cwnd_motorspeed = this;  // Motor Speed ȭ�鿡 ���� �ڵ� ���� ����
}

CScreen_Motor_Speed::~CScreen_Motor_Speed()
{
}

void CScreen_Motor_Speed::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CScreen_Motor_Speed)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_MSG_SAVING, m_msg_saving);
	DDX_Control(pDX, IDC_DGT_RUN_RATE, m_dgt_run_rate);
	DDX_Control(pDX, IDC_DGT_MANUAL_RATE, m_dgt_manual_rate);
	DDX_Control(pDX, IDC_MSG_RUN_RATE, m_msg_run_rate);
	DDX_Control(pDX, IDC_MSG_MANUAL_RATE, m_msg_manual_rate);
	DDX_Control(pDX, IDC_GROUP_MOTOR_SPEED_SET, m_group_motor_speed_set);
	DDX_Control(pDX, IDC_GROUP_MOTOR_SPEED_RATE, m_group_motor_speed_rate);
	DDX_Control(pDX, IDC_BTN_MS_APPLY, m_btn_ms_apply);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CScreen_Motor_Speed, CFormView)
	//{{AFX_MSG_MAP(CScreen_Motor_Speed)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BTN_MS_APPLY, OnBtnMsApply)
	ON_BN_CLICKED(IDC_DGT_RUN_RATE, OnDgtRunRate)
	ON_BN_CLICKED(IDC_DGT_MANUAL_RATE, OnDgtManualRate)
	//}}AFX_MSG_MAP
	ON_MESSAGE(SSM_CLICK, OnCellClick)
	ON_MESSAGE(WM_MOTORSPEED_APPLY, OnMotorSpeed_Info_Apply)  // Motor Speed DATA�� APPLY ��Ű�� ���� ����� ���� �޽��� ����
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScreen_Motor_Speed diagnostics

#ifdef _DEBUG
void CScreen_Motor_Speed::AssertValid() const
{
	CFormView::AssertValid();
}

void CScreen_Motor_Speed::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CScreen_Motor_Speed message handlers

void CScreen_Motor_Speed::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();

// 	mp_msg_dlg = new CDialog_Event_Msg;
// 	mp_msg_dlg->Create();
// 	mp_msg_dlg->SetParent(this);
	
	// **************************************************************************
	// ��Ʈ�ѿ� ������ ��Ʈ �����Ѵ�                                             
	// **************************************************************************
	mp_motorspeed_font = NULL;
	mp_motorspeed_font = new CFont;
	mp_motorspeed_font->CreateFont(14,0,0,0,900,0,0,0,0,0,0,ANTIALIASED_QUALITY,0,"MS Sans Serif");
	// **************************************************************************
	
	mn_enable = TRUE;

	OnMotorSpeed_GroupBox_Set();
	OnMotorSpeed_Label_Set();
	OnMotroSpeed_LCD_Digital_Set();
		
	OnMotorSpeed_RATE_Digital_Counter_Set();

// 	OnMotorSpeed_Data_Set();							//���� ������ Data�� �޾ƿ´�.
// 	OnMotorSpeed_Data_BackUp();	

	OnMotorSpeed_Init_Layout();
	OnMotorSpeed_Digital_Counter_Set();

	if (st_work.mn_run_status != CTL_dSTOP)			// Stop ���°� �ƴϸ� Apply Button�� ��Ȱ��ȭ�� �ȴ�.
	{
		OnMotorSpeed_Controls_Enable(false);		// ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
	}

	OnMotorSpeed_Controls_Show(0);
}

void CScreen_Motor_Speed::OnDestroy() 
{
	int mn_response;  // ��ȭ ���ڿ� ���� ���� �� ���� ����
	int Ret;

	CDialog_Infor info_dlg;

	//���α׷��� ���������鼭 Save ���� �ʰ�, Form�� Destroy�Ǵ°��̶�� Setting�� �����Ѵٴ� ���̴�.
	//�񱳵� ���� ����.
	if (st_handler.b_program_exit == false)
	{
		Ret = OnMotorSpeed_Data_Comparison();

		if (Ret == CTLBD_RET_ERROR)
		{
			st_msg.mstr_confirm_msg = _T("Changed Data! Apply?");
			mn_response = info_dlg.DoModal();
			
			if (mn_response == IDOK)
			{
				OnMotorSpeed_Data_Apply();
			}
			else if (mn_response == IDCANCEL)
			{
				OnMotorSpeed_Data_Recovery();

				OnMotorSpeed_Data_Apply();
			}	
		}
	}

	// **************************************************************************
	// ������ ��Ʈ ���� �����Ѵ�                                                 
	// **************************************************************************
	delete mp_motorspeed_font;
	mp_motorspeed_font = NULL;
	// **************************************************************************

	// ************************************************************************** //
	// LCD ������ ���� ��ũ�� ���� �����Ѵ�                                       //
	// ************************************************************************** //
	m_msg_saving.StopScroll();
	// ************************************************************************** //

	st_handler.cwnd_motorspeed = NULL;		// Motor Speed ȭ�鿡 ���� �ڵ� ���� ���� ���� �ʱ�ȭ 
	
	CFormView::OnDestroy();	
}

void CScreen_Motor_Speed::OnMotorSpeed_GroupBox_Set()
{
	CSxLogFont speed_font(15,FW_SEMIBOLD,false,"MS Sans Serif");

	m_group_motor_speed_rate.SetFont(speed_font);
	m_group_motor_speed_rate.SetCatptionTextColor(RGB(145,25,0));
	m_group_motor_speed_rate.SetFontBold(TRUE);

	m_group_motor_speed_set.SetFont(speed_font);
	m_group_motor_speed_set.SetCatptionTextColor(RGB(145,25,0));
	m_group_motor_speed_set.SetFontBold(TRUE);
}

void CScreen_Motor_Speed::OnMotorSpeed_Label_Set()
{
	m_msg_run_rate.SetTextFont(mp_motorspeed_font);
	m_msg_run_rate.SetColor(RGB(0, 0, 0), RGB(255, 255, 255), 3, 2);
	m_msg_run_rate.SetTextAlign(CFloatST::STA_CENTER, 10);

	m_msg_manual_rate.SetTextFont(mp_motorspeed_font);
	m_msg_manual_rate.SetColor(RGB(0, 0, 0), RGB(255, 255, 255), 3, 2);
	m_msg_manual_rate.SetTextAlign(CFloatST::STA_CENTER, 10);
}

void CScreen_Motor_Speed::OnMotorSpeed_Data_Set()
{
	for (int i = 0; i < MOT_MAXMOTOR; i++)
	{
		md_vel[i][1] =		COMI.md_spd_vel[i][0];
		md_acc[i][1] =		COMI.md_spd_vel[i][1];
		md_dec[i][1] =		COMI.md_spd_vel[i][2];
		
		md_home[i][1] =		COMI.md_spd_home[i];
		md_jog[i][1] =		st_motor[i].md_spd_jog;
		mn_allow[i][1] =	COMI.mn_allow_value[i];

		md_limit_m[i][1]	= COMI.md_limit_position[i][0];
		md_limit_p[i][1]	= COMI.md_limit_position[i][1];
	}

	mn_run_speed[1] =		st_basic.nRunSpeed;
	mn_manual_speed[1] =	st_basic.nManualSpeed;

	OnMotorSpeed_Data_BackUp();
}

void CScreen_Motor_Speed::OnMotorSpeed_Data_Recovery()
{
	for (int i = 0; i < MOT_MAXMOTOR; i++)
	{
		md_acc[i][1] =			md_acc[i][0];
		md_dec[i][1] =			md_dec[i][0];
		md_vel[i][1] =			md_vel[i][0];

		md_home[i][1] =			md_home[i][0];
		md_jog[i][1] =			md_jog[i][0];

		mn_allow[i][1] =		mn_allow[i][0];

		md_limit_m[i][1] =		md_limit_m[i][0];
		md_limit_p[i][1] =		md_limit_p[i][0];
	}

	mn_run_speed[1] =		mn_run_speed[0];
	mn_manual_speed[1] =	mn_manual_speed[0];
}

int CScreen_Motor_Speed::OnMotorSpeed_Data_Comparison()
{
	int Ret = CTLBD_RET_GOOD;

	for (int i = 0; i < MOT_MAXMOTOR; i++)
	{
		if (md_acc[i][0] !=	md_acc[i][1])				Ret = CTLBD_RET_ERROR;
		if (md_dec[i][0] !=	md_dec[i][1])				Ret = CTLBD_RET_ERROR;
		if (md_vel[i][0] !=	md_vel[i][1])				Ret = CTLBD_RET_ERROR;

		if (md_home[i][0] != md_home[i][1])				Ret = CTLBD_RET_ERROR;
		if (md_jog[i][0] !=	md_jog[i][1])				Ret = CTLBD_RET_ERROR;

		if (mn_allow[i][0] != mn_allow[i][1])			Ret = CTLBD_RET_ERROR;

		if (md_limit_m[i][0] !=	md_limit_m[i][1])		Ret = CTLBD_RET_ERROR;
		if (md_limit_p[i][0] !=	md_limit_p[i][1])		Ret = CTLBD_RET_ERROR;
	}

	if (mn_run_speed[0] != mn_run_speed[1])				Ret = CTLBD_RET_ERROR;
	if (mn_manual_speed[0] != mn_manual_speed[1])		Ret = CTLBD_RET_ERROR;

	return Ret;
}

void CScreen_Motor_Speed::OnMotorSpeed_Data_Apply()
{
	int i;

	for (i = 0; i < MOT_MAXMOTOR; i++)
	{
		COMI.md_spd_vel[i][0] =			md_vel[i][1];
		COMI.md_spd_vel[i][1] =			md_acc[i][1];
		COMI.md_spd_vel[i][2] =			md_dec[i][1];
		
		COMI.md_spd_home[i] =			md_home[i][1];

		st_motor[i].md_spd_jog =		md_jog[i][1];
		COMI.mn_allow_value[i] =		mn_allow[i][1];
		st_motor[i].mn_allow =			mn_allow[i][1];

		COMI.md_limit_position[i][1] = md_limit_p[i][1];
		COMI.md_limit_position[i][0] = md_limit_m[i][1];
	}

	st_basic.nRunSpeed =	mn_run_speed[1];
	st_basic.nManualSpeed = mn_manual_speed[1];
	COMI.mn_runspeed_rate = mn_run_speed[1];
	COMI.mn_manualspeed_rate = mn_manual_speed[1];

	Func.OnMot_Speed_Setting();
}

void CScreen_Motor_Speed::OnMotorSpeed_Data_BackUp()
{
	for (int i = 0; i < MOT_MAXMOTOR; i++)
	{
		md_acc[i][0] =					md_acc[i][1];
		md_dec[i][0] =					md_dec[i][1];
		md_vel[i][0] =					md_vel[i][1];

		md_home[i][0] =					md_home[i][1];
		md_jog[i][0] =					md_jog[i][1];

		mn_allow[i][0] =				mn_allow[i][1];

		md_limit_m[i][0] =				md_limit_m[i][1];
		md_limit_p[i][0] =				md_limit_p[i][1];
	}
	
	mn_run_speed[0] =					mn_run_speed[1];
	mn_manual_speed[0] =				mn_manual_speed[1];
}

// ******************************************************************************
//  Motor Speed ȭ�� ���� ���� ��û �޽���                                       
// ******************************************************************************
LRESULT CScreen_Motor_Speed::OnMotorSpeed_Info_Apply(WPARAM wParam, LPARAM lParam)  
{
	OnMotorSpeed_Data_Apply();			// ȭ�� ���� ���� ���� ������ ���� �Լ�

	OnMotorSpeed_Data_BackUp();

	return 0;
}

void CScreen_Motor_Speed::OnMotorSpeed_RATE_Digital_Counter_Set()
{	
	m_dgt_run_rate.SetStyle(CDigit::DS_INT, 3, CDigit::DC_BLACK);
	m_dgt_manual_rate.SetStyle(CDigit::DS_INT, 3, CDigit::DC_BLACK);
}

void CScreen_Motor_Speed::OnMotorSpeed_Digital_Counter_Set()
{
	m_dgt_run_rate.SetVal(mn_run_speed[1]);
	m_dgt_manual_rate.SetVal(mn_manual_speed[1]);
}

void CScreen_Motor_Speed::OnBtnMsApply() 
{
	int n_response;  // ��ȭ ���� ���� �÷���

	CDialog_Select  select_dlg;

	st_msg.mstr_confirm_msg = _T("Motor Speed : Setting Data Apply!");

	n_response = select_dlg.DoModal();

	if (n_response == IDOK)
	{
		OnMotorSpeed_Controls_Show(1);
		OnMotorSpeed_Data_Apply();			// ȭ�� ���� ���� ���� ������ ���� �Լ�
		OnMotorSpeed_LogFile_Create();
		OnMotorSpeed_Data_BackUp();
		mcls_motorspeed.OnMotorSpeed_Set_Data_Save();
		OnMotorSpeed_Controls_Show(0);




	}
	else if (n_response == IDCANCEL)
	{

	}
}

void CScreen_Motor_Speed::OnDgtRunRate() 
{
	int n_response;	// ��ȭ ���ڿ� ���� ���� �� ���� ����
	CString str_temp;  // ������ ���� �ӽ� ���� ���� 
	char chr_buf[20] ;

	if (mn_enable != TRUE)	return;
	
	CDialog_KeyPad pad_dlg;
	
	mn_run_speed[1] = m_dgt_run_rate.GetVal();
	str_temp = LPCTSTR(_itoa(mn_run_speed[1], chr_buf, 10));
	
	st_msg.mstr_keypad_msg = _T("Running Speed Rate Set");
    
	st_msg.mstr_keypad_val = str_temp;
	
	st_msg.mstr_pad_high_limit = "100";
	st_msg.mstr_pad_low_limit = "1";
	st_msg.mn_dot_use = FALSE;
	CRect r;
	
	m_dgt_run_rate.GetWindowRect(&r);
	
	pad_dlg.m_ptRef = CPoint(r.right, r.top);
	pad_dlg.m_ptRefLeft = CPoint(r.left, r.top);
	
	n_response = pad_dlg.DoModal();
	
	if (n_response == IDOK)
	{
		str_temp = st_msg.mstr_keypad_val;
		mn_run_speed[1] = atoi(str_temp);
		
		m_dgt_run_rate.SetVal(mn_run_speed[1]);
	}
	else if (n_response == IDCANCEL)
	{
		
	}
}

void CScreen_Motor_Speed::OnDgtManualRate() 
{
	int n_response;	// ��ȭ ���ڿ� ���� ���� �� ���� ����
	CString str_temp;  // ������ ���� �ӽ� ���� ���� 
	char chr_buf[20] ;

	if (mn_enable != TRUE)	return;
	
	CDialog_KeyPad pad_dlg;
	
	mn_manual_speed[1] = m_dgt_manual_rate.GetVal();
	str_temp = LPCTSTR(_itoa(mn_manual_speed[1], chr_buf, 10));
	
	st_msg.mstr_keypad_msg = _T("Manual Speed Rate Set");
    
	st_msg.mstr_keypad_val = str_temp;
	
	st_msg.mstr_pad_high_limit = "100";
	st_msg.mstr_pad_low_limit = "1";
	st_msg.mn_dot_use = FALSE;
	CRect r;
	
	m_dgt_manual_rate.GetWindowRect(&r);
	
	pad_dlg.m_ptRef = CPoint(r.right, r.top);
	pad_dlg.m_ptRefLeft = CPoint(r.left, r.top);
	
	n_response = pad_dlg.DoModal();
	
	if (n_response == IDOK)
	{
		str_temp = st_msg.mstr_keypad_val;
		mn_manual_speed[1] = atoi(str_temp);
		
		m_dgt_manual_rate.SetVal(mn_manual_speed[1]);
	}
	else if (n_response == IDCANCEL)
	{
		
	}
}

void CScreen_Motor_Speed::OnMotorSpeed_Controls_Enable(bool b_state)
{
	m_btn_ms_apply.EnableWindow(b_state);

	mn_enable = b_state;
}

void CScreen_Motor_Speed::OnMotorSpeed_Init_Layout()
{
	int i, j;
	CString strTmp;
	CString strHeader[9] = {"Axis", "Accel(ms)", "Decel(ms)", "Velocity(mm/s)", "Home(mm/s)", "Jog(mm/s)", "Allow(mm)", "- Limit", "+ Limit"};

	m_grid_speed = (TSpread*)GetDlgItem(IDC_CUSTOM_MOTOR_SPEED);
	
	mp_grid.GridFileOpen(m_grid_speed, st_path.mstr_motor_axis_map, "sheet1");
	                                   
	mn_motor_axis_cnt = 0;
	mn_motor_axis_cnt = atoi(mp_grid.GridCellText(m_grid_speed, 1, 2));
	
	if(mn_motor_axis_cnt == 0) return;
	
	for(i=0; i<mn_motor_axis_cnt; i++)
	{
		mstr_motor_axis_name[i]	= mp_grid.GridCellText(m_grid_speed, 4, (i+1)*2);
	}

	OnMotorSpeed_Data_Set();

	mp_grid.GridReset(m_grid_speed);
	// �빮�� 
	mp_grid.GridCellSelectDisplay(m_grid_speed, TRUE);
	mp_grid.GridRowHeader(m_grid_speed, FALSE);
	mp_grid.GridColHeader(m_grid_speed, TRUE);
	mp_grid.GridHorizontal(m_grid_speed, FALSE);
	mp_grid.GridVertical(m_grid_speed, TRUE);
	mp_grid.GridAutoSize(m_grid_speed, FALSE);
	
	mp_grid.GridCellRows(m_grid_speed, mn_motor_axis_cnt);
	mp_grid.GridCellCols(m_grid_speed, 9);
	
	for(i=0; i<mn_motor_axis_cnt+1; i++)
	{
		mp_grid.GridCellHeight_L(m_grid_speed, i, (double)30);
		
		if(i == 0)
		{
			for(j=0; j<9; j++)
			{
				switch(j)
				{
					case 0:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, (double)23);
						break;

					case 1:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, (double)12);
						break;

					case 2:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, (double)12);
						break;

					case 3:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, (double)12);
						break;

					case 4:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, (double)12);
						break;

					case 5:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, (double)12);
						break;

					case 6:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, (double)12);
						break;

					case 7:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, (double)12);
						break;

					case 8:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, (double)12);
						break;
				}

				mp_grid.GridCellFont(m_grid_speed, i, j+1, "MS Sans Serif", 14);
				mp_grid.GridCellColor(m_grid_speed, i, j+1, BLUE_D, WHITE_C);
				mp_grid.GridCellText(m_grid_speed, i, j+1, strHeader[j]);

				mp_grid.GridCellControlStatic(m_grid_speed, i, j+1);
			}
		}
		else
		{
			for(j=0; j<9; j++)
			{
				switch(j)
				{
					case 0:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, 23);

						mp_grid.GridCellFont(m_grid_speed, i, j+1, "MS Sans Serif", 14);
						mp_grid.GridCellColor(m_grid_speed, i, j+1, BLUE_D, WHITE_C);
						mp_grid.GridCellText(m_grid_speed, i, j+1, mstr_motor_axis_name[i-1]);
						break;

					case 1:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, 12);

						mp_grid.GridCellFont(m_grid_speed, i, j+1, "MS Sans Serif", 14);
						mp_grid.GridCellColor(m_grid_speed, i, j+1, RED_L, BLACK_C);
						strTmp.Format("%d", (int)md_acc[i-1][1]);
						mp_grid.GridCellText(m_grid_speed, i, j+1, strTmp);
						break;

					case 2:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, 12);

						mp_grid.GridCellFont(m_grid_speed, i, j+1, "MS Sans Serif", 14);
						mp_grid.GridCellColor(m_grid_speed, i, j+1, GREEN_L, BLACK_C);
						strTmp.Format("%d", (int)md_dec[i-1][1]);
						mp_grid.GridCellText(m_grid_speed, i, j+1, strTmp);
						break;

					case 3:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, 12);

						mp_grid.GridCellFont(m_grid_speed, i, j+1, "MS Sans Serif", 14);
						mp_grid.GridCellColor(m_grid_speed, i, j+1, YELLOW_L, BLACK_C);
						strTmp.Format("%d", (int)md_vel[i-1][1]);
						mp_grid.GridCellText(m_grid_speed, i, j+1, strTmp);
						break;

					case 4:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, 12);

						mp_grid.GridCellFont(m_grid_speed, i, j+1, "MS Sans Serif", 14);
						mp_grid.GridCellColor(m_grid_speed, i, j+1, YELLOW_L, BLACK_C);
						strTmp.Format("%d", (int)md_home[i-1][1]);
						mp_grid.GridCellText(m_grid_speed, i, j+1, strTmp);
						break;

					case 5:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, 12);

						mp_grid.GridCellFont(m_grid_speed, i, j+1, "MS Sans Serif", 14);
						mp_grid.GridCellColor(m_grid_speed, i, j+1, YELLOW_L, BLACK_C);
						strTmp.Format("%d", (int)md_jog[i-1][1]);
						mp_grid.GridCellText(m_grid_speed, i, j+1, strTmp);
						break;

					case 6:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, 12);

						mp_grid.GridCellFont(m_grid_speed, i, j+1, "MS Sans Serif", 14);
						mp_grid.GridCellColor(m_grid_speed, i, j+1, SKY_C, BLACK_C);
						strTmp.Format("%d", mn_allow[i-1][1]);
						mp_grid.GridCellText(m_grid_speed, i, j+1, strTmp);
						break;

					case 7:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, 12);
						
						mp_grid.GridCellFont(m_grid_speed, i, j+1, "MS Sans Serif", 14);
						mp_grid.GridCellColor(m_grid_speed, i, j+1, RED_L, BLACK_C);
						strTmp.Format("%.3f", md_limit_m[i-1][1]);
						mp_grid.GridCellText(m_grid_speed, i, j+1, strTmp);
						break;

					case 8:
						mp_grid.GridCellWidth_L(m_grid_speed, j+1, 12);
						
						mp_grid.GridCellFont(m_grid_speed, i, j+1, "MS Sans Serif", 14);
						mp_grid.GridCellColor(m_grid_speed, i, j+1, GREEN_L, BLACK_C);
						strTmp.Format("%.3f", md_limit_p[i-1][1]);
						mp_grid.GridCellText(m_grid_speed, i, j+1, strTmp);
						break;
				}
	
				mp_grid.GridCellControlStatic(m_grid_speed, i, j+1);
			}
		}
	}
}

void CScreen_Motor_Speed::GridColor(UINT nID, int row, int col, COLORREF bk, COLORREF tk)
{
	TSpread *Grid = (TSpread*)GetDlgItem(nID);
	Grid->SetColor(col, row, bk, tk);
	Grid->SetBackColorStyle(SS_BACKCOLORSTYLE_UNDERGRID);

	Grid = NULL;
	delete Grid;
}

void CScreen_Motor_Speed::GridControl(UINT nID, int type, int row, int col, int pos)
{
	TSpread *Grid = (TSpread*)GetDlgItem(nID);
	
	SS_CELLTYPE CellType;
	SS_DATEFORMAT dateFormat = { TRUE, '/', IDF_DDMMYY, FALSE };
	SS_TIMEFORMAT tmFormat;
	CString strList;
	strList = "combo1\tcombo2\tcombo3\tcombo4\tcombo5\tcombo6";
	double a = 0.5;

	switch (type)
	{
		case DATE:			
			Grid->SetTypeDate(&CellType, 0 , &dateFormat, NULL, NULL);
			break;

		case EDIT:
			Grid->SetTypeEdit(&CellType,ES_CENTER,60,SS_CHRSET_CHR,SS_CASE_NOCASE);
			break;

		case COMBO:
			// SetValue(col, row, data); data = ""0"(1����) data = "1"(2����) data = "2"(3����)
			Grid->SetTypeComboBox(&CellType, 0, strList);
			break;

		case BUTTON:
			if (pos == 0)
			{
				Grid->SetTypeButton(&CellType, SBS_DEFPUSHBUTTON, "Go", NULL, SUPERBTN_PICT_NONE,
					NULL, SUPERBTN_PICT_NONE, SUPERBTN_TYPE_NORMAL, 2, NULL);
			}
			else
			{
				Grid->SetTypeButton(&CellType, SBS_DEFPUSHBUTTON, "Read", NULL, SUPERBTN_PICT_NONE,
					NULL, SUPERBTN_PICT_NONE,SUPERBTN_TYPE_NORMAL, 2, NULL);
			}
			break;

		case STATIC:
			Grid->SetTypeStaticText(&CellType, SS_TEXT_CENTER | SS_TEXT_VCENTER);
			break;

		case TIME:
			tmFormat.b24Hour=TRUE;
			tmFormat.bSpin=FALSE;
			tmFormat.bSeconds=FALSE;
			tmFormat.cSeparator=':';
			Grid->SetTypeTime(&CellType, 0, &tmFormat, NULL, NULL);
			break;

		case PERCENT:
			Grid->SetTypePercentEx(&CellType,ES_LEFTALIGN,2,.01,100,".",0,0,0,0,1.001);
			break;

		case CHECK1:
			Grid->SetTypeCheckBox(&CellType,BS_CENTER, "", 
				"CheckUp", BT_BITMAP,
				"CheckDown", BT_BITMAP,
				"CheckFocusUp", BT_BITMAP,
				"CheckFocusDown", BT_BITMAP,
				"CheckDisabledUp", BT_BITMAP,
				"CheckDisabledDown", BT_BITMAP);
			break;

		case NUMBER:
			Grid->SetTypeNumberEx(&CellType,0,pos, 0, 10000,0,".",",",0,0,1,0,1.001);
			break;
	}
	
	Grid->SetCellType(col,row,&CellType);

	Grid = NULL;
	delete Grid;
}

void CScreen_Motor_Speed::GridData(UINT nID, int row, int col, CString data)
{
	TSpread *Grid = (TSpread*)GetDlgItem(nID);
	
	Grid->SetValue(col, row, data);

	Grid = NULL;
	delete Grid;
}

void CScreen_Motor_Speed::GridFont(UINT nID, int row, int col, int size)
{
	TSpread *Grid = (TSpread *)GetDlgItem(nID);
	HFONT font;
	CString strTemp;
	
	font = CreateFont(size, 0, 0, 0, FW_BOLD, 0, 0, 0, 0, 0, 0, 0, 0, "����ü");
	Grid->SetFont(col, row, font, TRUE);

	Grid = NULL;
	delete Grid;
}

void CScreen_Motor_Speed::GridMerge(UINT nID, int srow, int scol, int nrow, int ncol)
{
	TSpread *Grid = (TSpread*)GetDlgItem(nID);
	
	Grid->AddCellSpan(scol, srow, ncol, nrow);

	Grid = NULL;
	delete Grid;
}

void CScreen_Motor_Speed::OnCellClick(WPARAM wParam, LPARAM lParam)
{
	int nId = -1;
	LPSS_CELLCOORD lpcc = (LPSS_CELLCOORD)lParam;

	if (mn_enable != TRUE)	return;

	switch (wParam)
	{
	case IDC_CUSTOM_MOTOR_SPEED:
		nId = 0;
		break;
	}
	
	if (nId > -1)
	{
		if (lpcc->Col != 1)
		{
			OnChangeValue(nId, lpcc->Row, lpcc->Col);
		}
	}
}

void CScreen_Motor_Speed::OnChangeValue(int nid, int nrow, int ncol)
{
	TSpread *Grid; 
	char chvalue[100];
	char chText[100];
	char chPos[100];
	CString strText;
	CString strPos;
	double dvalue;
	CString strTmp, strTmp2;
	int i;

	Grid = NULL;
	delete Grid;	
	int n_response;		// ��ȭ ���ڿ� ���� ���� �� ���� ����
	CString str_temp;	// ������ ���� �ӽ� ���� ���� 

	if (ncol == 4 || ncol == 5 || ncol == 6 || ncol == 8 || ncol == 9)
	{
		if (st_handler.mn_level_speed != TRUE)
		{
			return;
		}
	}
	
	CDialog_KeyPad pad_dlg;

	if (nid == 0)
	{
		Grid = (TSpread*)GetDlgItem(IDC_CUSTOM_MOTOR_SPEED);
	
		Grid->GetValue(ncol, nrow, chvalue);
		dvalue = atof(chvalue);
		strTmp.Format("%.0f", dvalue);

		Grid->GetValue(1, nrow, chText);
		strText = chText;
		Grid->GetValue(ncol, 1, chPos);
		strPos = chPos;

		st_msg.mstr_keypad_msg.Format("[%s Motor] %s speed set", strText, strPos);
		
		st_msg.mstr_keypad_val = strTmp;
		
		st_msg.mn_dot_use = CTL_NO;
		pad_dlg.m_point = CTL_YES;

		if (ncol == 2 || ncol == 3)
		{
			st_msg.mstr_pad_high_limit = "5000";
			st_msg.mstr_pad_low_limit = "10";
		}
		else if (ncol == 7)
		{
			st_msg.mn_dot_use = CTL_YES;
			st_msg.mstr_pad_high_limit = "10";
			st_msg.mstr_pad_low_limit = "0";
		}
		else if (ncol == 8)
		{
			st_msg.mstr_pad_high_limit = "5000";
			st_msg.mstr_pad_low_limit = "-100";
		}
		else
		{
			st_msg.mstr_pad_high_limit = "5000";
			st_msg.mstr_pad_low_limit = "1";
		}
		
		n_response = pad_dlg.DoModal();
		
		if (n_response == IDOK)
		{
			strTmp = st_msg.mstr_keypad_val;

			if (nrow == 0)			// ��ü
			{
				for (i = 0; i < MOT_MAXMOTOR; i++)
				{
					if (ncol == 1)
					{
					}
					else if (ncol == 2)
					{
						md_acc[i][1] = atof(strTmp);
						strTmp.Format("%.0f", md_acc[i][1]);
					}
					else if (ncol == 3)
					{
						md_dec[i][1] = atof(strTmp);
						strTmp.Format("%.0f", md_dec[i][1]);
					}
					else if (ncol == 4)
					{
						md_vel[i][1] = atof(strTmp);
						strTmp.Format("%.0f", md_vel[i][1]);
					}
					else if (ncol == 5)
					{
						md_home[i][1] = atof(strTmp);
						strTmp.Format("%.0f", md_home[i][1]);
					}
					else if (ncol == 6)
					{
						md_jog[i][1] = atof(strTmp);
						strTmp.Format("%.0f", md_jog[i][1]);
					}
					else if (ncol == 7)
					{
						mn_allow[i][1] = atoi(strTmp);
						strTmp.Format("%d", mn_allow[i][1]);
					}
					else if (ncol == 8)
					{
						md_limit_m[i][1] = atoi(strTmp);
						strTmp.Format("%.0f", md_limit_m[i][1]);
					}
					else if (ncol == 9)
					{
						md_limit_p[i][1] = atoi(strTmp);
						strTmp.Format("%.0f", md_limit_p[i][1]);
					}
					
					Grid->SetValue(ncol, i + 1, strTmp);
				}

				return;
			}
			
			if (ncol == 1)
			{
			}
			else if (ncol == 2)
			{
				md_acc[nrow-1][1] = atof(strTmp);
				strTmp.Format("%.0f", md_acc[nrow-1][1]);
			}
			else if (ncol == 3)
			{
				md_dec[nrow-1][1] = atof(strTmp);
				strTmp.Format("%.0f", md_dec[nrow-1][1]);
			}
			else if (ncol == 4)
			{
				md_vel[nrow-1][1] = atof(strTmp);
				strTmp.Format("%.0f", md_vel[nrow-1][1]);
			}
			else if (ncol == 5)
			{
				md_home[nrow-1][1] = atof(strTmp);
				strTmp.Format("%.0f", md_home[nrow-1][1]);
			}
			else if (ncol == 6)
			{
				md_jog[nrow-1][1] = atof(strTmp);
				strTmp.Format("%.0f", md_jog[nrow-1][1]);
			}
			else if (ncol == 7)
			{
				mn_allow[nrow-1][1] = atoi(strTmp);
				strTmp.Format("%d", mn_allow[nrow-1][1]);
			}
			
			Grid->SetValue(ncol, nrow, strTmp);
		}
		else if (n_response == IDCANCEL)
		{
			
		}
	}
}

void CScreen_Motor_Speed::OnMotroSpeed_LCD_Digital_Set()
{
	m_msg_saving.SetNumberOfLines(1);
	m_msg_saving.SetXCharsPerLine(28);
	m_msg_saving.SetSize(CMatrixStatic::LARGE);
	m_msg_saving.SetDisplayColors(RGB(0, 0, 0), RGB(255, 60, 0), RGB(103, 30, 0));
	m_msg_saving.AdjustClientXToSize(28);
	m_msg_saving.AdjustClientYToSize(1);
	m_msg_saving.SetAutoPadding(true, '!');
	m_msg_saving.DoScroll(300, CMatrixStatic::LEFT);
}

void CScreen_Motor_Speed::OnMotorSpeed_Controls_Show(int n_state)
{
	switch(n_state)
	{
	case 0 :
		m_msg_saving.ShowWindow(SW_HIDE);
		break;
		
	case 1: 
		m_msg_saving.ShowWindow(SW_SHOW);
		m_msg_saving.SetText(_T("Motor speed data saving~...."));
		break;
		
	default:
		break;
	}
}

void CScreen_Motor_Speed::OnMotorSpeed_LogFile_Create()
{
	CString str_msg;
	CString str_data;
	CString str_old_data;
	CString str_motor;

	int i;

	for (i = 0; i < MOT_MAXMOTOR; i++)
	{
		str_motor = Func.Get_MotorName(i);

		if (md_vel[i][1] != md_vel[i][0])
		{
			str_data.Format("%d", md_vel[0][1]);
			str_old_data.Format("%d", md_vel[0][0]);
			str_msg.Format("[Motor Speed] %s Robot Vel Speed was changed by %s To %s", str_motor, str_old_data, str_data);
			Func.On_LogFile_Add(0, str_msg);
			Func.On_LogFile_Add(99, str_msg);
		}

		if (md_acc[i][1] != md_acc[i][0])
		{
			str_data.Format("%d", md_acc[0][1]);
			str_old_data.Format("%d", md_acc[0][0]);
			str_msg.Format("[Motor Speed] %s Robot Acc Speed was changed by %s To %s", str_motor, str_old_data, str_data);
			Func.On_LogFile_Add(0, str_msg);
			Func.On_LogFile_Add(99, str_msg);
		}

		if (md_dec[i][1] != md_dec[i][0])
		{
			str_data.Format("%d", md_dec[0][1]);
			str_old_data.Format("%d", md_dec[0][0]);
			str_msg.Format("[Motor Speed] %s Robot Dec Speed was changed by %s To %s", str_motor, str_old_data, str_data);
			Func.On_LogFile_Add(0, str_msg);
			Func.On_LogFile_Add(99, str_msg);
		}
		
		if (md_home[i][1] != md_home[i][0])
		{
			str_data.Format("%d", md_home[0][1]);
			str_old_data.Format("%d", md_home[0][0]);
			str_msg.Format("[Motor Speed] %s Robot Home Speed was changed by %s To %s", str_motor, str_old_data, str_data);
			Func.On_LogFile_Add(0, str_msg);
			Func.On_LogFile_Add(99, str_msg);
		}

		if (md_jog[i][1] != md_jog[i][0])
		{
			str_data.Format("%d", md_jog[0][1]);
			str_old_data.Format("%d", md_jog[0][0]);
			str_msg.Format("[Motor Speed] %s Robot Jog Speed was changed by %s To %s", str_motor, str_old_data, str_data);
			Func.On_LogFile_Add(0, str_msg);
			Func.On_LogFile_Add(99, str_msg);
		}

		if (mn_allow[i][1] != mn_allow[i][0])
		{
			str_data.Format("%d", mn_allow[0][1]);
			str_old_data.Format("%d", mn_allow[0][0]);
			str_msg.Format("[Motor Speed] %s Robot Allow was changed by %s To %s", str_motor, str_old_data, str_data);
			Func.On_LogFile_Add(0, str_msg);
			Func.On_LogFile_Add(99, str_msg);
		}
	}
	
	if (mn_run_speed[1] != mn_run_speed[0])
	{
		str_data.Format("%d", mn_run_speed[1]);
		str_old_data.Format("%d", mn_run_speed[0]);
		str_msg.Format("[Motor Speed] Run Speed was changed by %s To %s", str_old_data, str_data);
		Func.On_LogFile_Add(0, str_msg);
		Func.On_LogFile_Add(99, str_msg);
	}

	if (mn_manual_speed[1] != mn_manual_speed[0])
	{
		str_data.Format("%d", mn_manual_speed[1]);
		str_old_data.Format("%d", mn_manual_speed[0]);
		str_msg.Format("[Motor Speed] Manual Speed was changed by %s To %s", str_old_data, str_data);
		Func.On_LogFile_Add(0, str_msg);
		Func.On_LogFile_Add(99, str_msg);
	}
}