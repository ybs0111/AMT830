// Dialog_Manual_Module.cpp : implementation file
//

#include "stdafx.h"
#include "handler.h"
#include "Dialog_Manual_Module.h"
#include "Public_Function.h"
#include "Cmmsdk.h"//20121006
#include "CtlBd_Function.h"
#include "CtlBd_Library.h"
#include "FastechPublic_IO.h"
#include "Dialog_Message.h"
#include "Dialog_KeyPad.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define TM_STATUS_CHECK		100
#define TM_POSITION_CHECK	200
#define TM_HOME_CHECK		300
#define TM_MOVE_CHECK		400

#define AXIS_NUM			0

/////////////////////////////////////////////////////////////////////////////
// CDialog_Manual_Module dialog


CDialog_Manual_Module::CDialog_Manual_Module(CWnd* pParent /*=NULL*/)
	: CDialog(CDialog_Manual_Module::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialog_Manual_Module)
	//}}AFX_DATA_INIT
	m_n_move_mode = 0;
}


void CDialog_Manual_Module::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialog_Manual_Module)
	DDX_Control(pDX, IDC_BTN_STOP, m_btn_stop);
	DDX_Control(pDX, IDC_BTN_RIGHT, m_btn_right);
	DDX_Control(pDX, IDC_BTN_HOME, m_btn_home);
	DDX_Control(pDX, IDC_BTN_LEFT, m_btn_left);
	DDX_Control(pDX, IDC_GROUP_MOVE, m_group_motormove);
	DDX_Control(pDX, IDC_GROUP_MOTOR, m_group_motor);
	DDX_Control(pDX, IDC_CMB_MOTOR_POS, m_cmb_motor_pos);
	DDX_Control(pDX, IDC_BTN_GUIDE2_ONFF, m_btn_guide2_onoff);
	DDX_Control(pDX, IDC_MSG_BUFFER4, m_msg_buffer4);
	DDX_Control(pDX, IDC_MSG_BUFFER3, m_msg_buffer3);
	DDX_Control(pDX, IDC_MSG_BUFFER2, m_msg_buffer2);
	DDX_Control(pDX, IDC_MSG_BUFFER1, m_msg_buffer1);
	DDX_Control(pDX, IDC_MSG_BUFFER_MODULE, m_msg_buffer_module);
	DDX_Control(pDX, IDC_IO_GUIDE2_ONOFF, m_io_guide2_onoff);
	DDX_Control(pDX, IDC_IO_CLAMP2_ONOFF, m_io_clamp2_onoff);
	DDX_Control(pDX, IDC_IO_CLAMP1_ONOFF, m_io_clamp1_onoff);
	DDX_Control(pDX, IDC_CMB_TRAY_POS, m_cmb_tray_pos);
	DDX_Control(pDX, IDC_CMB_MODULE_POS, m_cmb_module_pos);
	DDX_Control(pDX, IDC_CMB_BUFFER_POS, m_cmb_buffer_pos);
	DDX_Control(pDX, IDC_BTN_CLAMP2_ONOFF, m_btn_clamp2_onoff);
	DDX_Control(pDX, IDC_BTN_CLAMP1_ONOFF, m_btn_clamp1_onoff);
	DDX_Control(pDX, IDC_BTN_GO_TRAY_POS, m_btn_go_tray_pos);
	DDX_Control(pDX, IDC_BTN_GO_STEP_RBT_MOVE, m_btn_go_step_rbt_move);
	DDX_Control(pDX, IDC_BTN_GO_BUFFER_POS, m_btn_go_buffer_pos);
	DDX_Control(pDX, IDC_BTN_GO_MODULE_POS, m_btn_go_module_pos);

	DDX_Control(pDX, IDC_BTN_FINGER_SOL_ALL, m_btn_finger_sol_all);
	DDX_Control(pDX, IDC_BTN_FINGER_SOL_2, m_btn_finger_sol2);
	DDX_Control(pDX, IDC_BTN_FINGER_SOL_1, m_btn_finger_sol1);
	DDX_Control(pDX, IDC_BTN_PICKER_SOL_ALL, m_btn_picker_sol_all);
	DDX_Control(pDX, IDC_BTN_PICKER_SOL_2, m_btn_picker_sol2);
	DDX_Control(pDX, IDC_BTN_PICKER_SOL_1, m_btn_picker_sol1);
	DDX_Control(pDX, IDC_MSG_FINGER_SOL, m_msg_finger_sol);
	DDX_Control(pDX, IDC_MSG_PICKER_SOL, m_msg_picker_sol);
	DDX_Control(pDX, IDC_MSG_PICKER_2, m_msg_picker2);
	DDX_Control(pDX, IDC_MSG_PICKER_1, m_msg_picker1);
	DDX_Control(pDX, IDC_BTN_BUFFER_MODULE_SOL4, m_btn_buffer_module_sol4);
	DDX_Control(pDX, IDC_BTN_BUFFER_MODULE_SOL3, m_btn_buffer_module_sol3);
	DDX_Control(pDX, IDC_BTN_BUFFER_MODULE_SOL2, m_btn_buffer_module_sol2);
	DDX_Control(pDX, IDC_BTN_BUFFER_MODULE_SOL1, m_btn_buffer_module_sol1);
	DDX_Control(pDX, IDC_GROUP_BUFFER_RBT_MOVE, m_group_buffer_rbt_move);
	DDX_Control(pDX, IDC_GROUP_BUFFER, m_group_buffer);
	DDX_Control(pDX, IDC_GROUP_TRAY_POS_CLAMP_GUIDE, m_group_tray_pos_clamp_guide);
	DDX_Control(pDX, IDC_GROUP_RBT_STEP_MOVE, m_group_step_rbt_move);
	DDX_Control(pDX, IDC_GROUP_RBT_MOVE, m_group_picker_rbt_move);
	DDX_Control(pDX, IDC_GROUP_PICKER, m_group_picker);
	DDX_Control(pDX, IDC_GROUP_CYLINDER, m_group_cylinder);
	DDX_Control(pDX, IDC_BTN_CYLINDER_SOL, m_btn_cylinder_sol);
	DDX_Control(pDX, IDC_MSG_CYLINDER_SOL, m_msg_cylinder_sol);

	//}}AFX_DATA_MAP
}



BEGIN_MESSAGE_MAP(CDialog_Manual_Module, CDialog)
	//{{AFX_MSG_MAP(CDialog_Manual_Module)
	ON_BN_CLICKED(IDC_BTN_GO_TRAY_POS, OnBtnGoTrayPos)
	ON_BN_CLICKED(IDC_BTN_GO_BUFFER_POS, OnBtnGoBufferPos)
	ON_BN_CLICKED(IDC_BTN_CLAMP1_ONOFF, OnBtnClamp1Onoff)
	ON_BN_CLICKED(IDC_BTN_CLAMP2_ONOFF, OnBtnClamp2Onoff)
	ON_BN_CLICKED(IDC_BTN_GUIDE2_ONFF, OnBtnGuide2Onff)
	ON_BN_CLICKED(IDC_BTN_PICKER_SOL_1, OnBtnPickerSol1)
	ON_BN_CLICKED(IDC_BTN_PICKER_SOL_2, OnBtnPickerSol2)
	ON_BN_CLICKED(IDC_BTN_PICKER_SOL_ALL, OnBtnPickerSolAll)
	ON_BN_CLICKED(IDC_BTN_FINGER_SOL_1, OnBtnFingerSol1)
	ON_BN_CLICKED(IDC_BTN_FINGER_SOL_2, OnBtnFingerSol2)
	ON_BN_CLICKED(IDC_BTN_FINGER_SOL_ALL, OnBtnFingerSolAll)
	ON_BN_CLICKED(IDC_BTN_BUFFER_MODULE_SOL1, OnBtnBufferModuleSol1)
	ON_BN_CLICKED(IDC_BTN_BUFFER_MODULE_SOL2, OnBtnBufferModuleSol2)
	ON_BN_CLICKED(IDC_BTN_BUFFER_MODULE_SOL3, OnBtnBufferModuleSol3)
	ON_BN_CLICKED(IDC_BTN_BUFFER_MODULE_SOL4, OnBtnBufferModuleSol4)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BTN_STOP, OnBtnStop)
	ON_BN_CLICKED(IDC_BTN_HOME, OnBtnHome)
	ON_BN_CLICKED(IDC_BTN_GO_STEP_RBT_MOVE, OnBtnGoStepRbtMove)
	ON_CBN_SELCHANGE(IDC_CMB_MOTOR_POS, OnSelchangeCmbMotorPos)
	ON_BN_CLICKED(IDC_BTN_GO_MODULE_POS, OnBtnGoModulePos)
	ON_BN_CLICKED(IDC_BTN_CYLINDER_SOL, OnBtnCylinderSol)
	//}}AFX_MSG_MAP
/////////////////////////////20121006
	ON_MESSAGE(SSM_CLICK  , OnCellClick)
	ON_MESSAGE(WMU_CHILD_LBUTTON_DOWN, OnUserLButtonDown)
	ON_MESSAGE(WMU_CHILD_LBUTTON_UP, OnUserLButtonUp)
/////////////////////////////

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialog_Manual_Module message handlers

BOOL CDialog_Manual_Module::OnInitDialog() 
{
	CDialog::OnInitDialog();
	int nMotorPos = 0;
	
	m_p_font = NULL;
	m_p_font = new CFont;
	m_p_font->CreateFont(20,0,0,0,900,0,0,0,0,0,0,ANTIALIASED_QUALITY,0,"MS Sans Serif");

	m_load_combo_font = NULL;
	m_load_combo_font = new CFont;
	m_load_combo_font->CreateFont(55, 0, 0, 0, 300, 0, 0, 0, 0, 0, 0, ANTIALIASED_QUALITY, 0, "Arial");

//////////////////////////////////////////////////// 20121006
	m_motor_font = NULL;
	m_motor_font = new CFont;
	m_motor_font->CreateFont(20,0,0,0,900,0,0,0,0,0,0,ANTIALIASED_QUALITY,0,"MS Sans Serif");

	m_d_data = 10;
////////////////////////////////////////////////////

	Init_GroupBox_Set();
	Init_Label();
	Init_Data();
	Init_Grid_Info();//20121006

	Init_Button();
	OnRead_IO_Check();
	OnSite_IO_Button_Status();
	OnSiteRbt_Button_Status();

	m_cmb_motor_pos.SetCurSel(nMotorPos);// .Init_Tab(this, m_n_axis);

	if(nMotorPos == 0)
	{
		m_n_axis = M_M_RBT_Y;
	}
	else if(nMotorPos == 1)
	{
		m_n_axis = M_M_RBT_Z;
	}
	else if(nMotorPos == 2)
	{
		m_n_axis = M_LDM_STACKER_1;
	}
	else if(nMotorPos == 3)
	{
		m_n_axis = M_LDM_STACKER_2;
	}
	else if(nMotorPos == 4)
	{
		m_n_axis = M_LDM_STACKER_MOVE;
	}
	else
	{
		m_n_axis = M_WORK_BUFFER_1 + nMotorPos - 5;
	}
	
	if (COMI.mn_motorbd_init_end)
	{
		SetTimer(TM_STATUS_CHECK, 100, NULL);
		SetTimer(TM_POSITION_CHECK, 100, NULL);
	}

	SetTimer(TMR_IO_MONITOR_CMD, 50, NULL);		// IO ���� �б� Ÿ�̸� ����
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
//////////////////////////////////////////////////// 20121006
void CDialog_Manual_Module::Init_Grid_Info()
{
	int   i, j;
	CString str_tmp;

	m_grid_motor_info = (TSpread*)GetDlgItem(IDC_CUSTOM_MOTOR_INFO);
	
	m_p_grid.GridReset(m_grid_motor_info);
	// �빮�� 
	m_p_grid.GridCellSelectDisplay(m_grid_motor_info, TRUE);
	
	m_p_grid.GridRowHeader(m_grid_motor_info, FALSE);
	m_p_grid.GridColHeader(m_grid_motor_info, FALSE);
	m_p_grid.GridHorizontal(m_grid_motor_info, FALSE);
	m_p_grid.GridVertical(m_grid_motor_info, FALSE);
	m_p_grid.GridAutoSize(m_grid_motor_info, FALSE);
	m_p_grid.GridAutoSize(m_grid_motor_info, FALSE);
	m_p_grid.GridCellRows(m_grid_motor_info, 8);
	m_p_grid.GridCellCols(m_grid_motor_info, 6);
	
	for(i=0; i<8; i++)
	{
		m_p_grid.GridCellHeight_L(m_grid_motor_info, i+1, 20);
		for(j=0; j<6; j++)
		{
			m_p_grid.GridCellWidth_L(m_grid_motor_info, j+1, 9.5);
	
			m_p_grid.GridCellControlStatic(m_grid_motor_info, i+1, j+1);
		}
	}

	if (m_n_home == 0)
	{
		if (m_n_sd == 1)
		{
			if (m_n_minus_el == 1)
			{
				m_p_grid.GridCellMerge(m_grid_motor_info, 1, 1, 1, 2);
				m_p_grid.GridCellFont(m_grid_motor_info, 1, 1, "MS Sans Serif", 12);
				m_p_grid.GridCellColor(m_grid_motor_info, 1, 1, BLUE_D, WHITE_C);
				m_p_grid.GridCellText(m_grid_motor_info, 1, 1, "�� ML");
				
				m_p_grid.GridCellMerge(m_grid_motor_info, 2, 1, 1, 2);
				m_p_grid.GridCellFont(m_grid_motor_info, 2, 1, "MS Sans Serif", 12);
				m_p_grid.GridCellColor(m_grid_motor_info, 2, 1, BLACK_L, WHITE_C);
				m_p_grid.GridCellText(m_grid_motor_info, 2, 1, "");
			}
			
			m_p_grid.GridCellMerge(m_grid_motor_info, 1, 3, 1, 2);
			m_p_grid.GridCellFont(m_grid_motor_info, 1, 3, "MS Sans Serif", 12);
			m_p_grid.GridCellColor(m_grid_motor_info, 1, 3, BLUE_D, WHITE_C);
			m_p_grid.GridCellText(m_grid_motor_info, 1, 3, "SD");
			
			m_p_grid.GridCellMerge(m_grid_motor_info, 2, 3, 1, 2);
			m_p_grid.GridCellFont(m_grid_motor_info, 2, 3, "MS Sans Serif", 12);
			m_p_grid.GridCellColor(m_grid_motor_info, 2, 3, BLACK_L, WHITE_C);
			m_p_grid.GridCellText(m_grid_motor_info, 2, 3, "");

			if (m_n_plus_el == 1)
			{
				m_p_grid.GridCellMerge(m_grid_motor_info, 1, 5, 1, 2);
				m_p_grid.GridCellFont(m_grid_motor_info, 1, 5, "MS Sans Serif", 12);
				m_p_grid.GridCellColor(m_grid_motor_info, 1, 5, BLUE_D, WHITE_C);
				m_p_grid.GridCellText(m_grid_motor_info, 1, 5, "�� PL");
				
				m_p_grid.GridCellMerge(m_grid_motor_info, 2, 5, 1, 2);
				m_p_grid.GridCellFont(m_grid_motor_info, 2, 5, "MS Sans Serif", 12);
				m_p_grid.GridCellColor(m_grid_motor_info, 2, 5, BLACK_L, WHITE_C);
				m_p_grid.GridCellText(m_grid_motor_info, 2, 5, "");
			}
		}
		else
		{
			if (m_n_minus_el == 1)
			{
				m_p_grid.GridCellMerge(m_grid_motor_info, 1, 1, 1, 3);
				m_p_grid.GridCellFont(m_grid_motor_info, 1, 1, "MS Sans Serif", 12);
				m_p_grid.GridCellColor(m_grid_motor_info, 1, 1, BLUE_D, WHITE_C);
				m_p_grid.GridCellText(m_grid_motor_info, 1, 1, "- ML");
				
				m_p_grid.GridCellMerge(m_grid_motor_info, 2, 1, 1, 3);
				m_p_grid.GridCellFont(m_grid_motor_info, 2, 1, "MS Sans Serif", 12);
				m_p_grid.GridCellColor(m_grid_motor_info, 2, 1, BLACK_L, WHITE_C);
				m_p_grid.GridCellText(m_grid_motor_info, 2, 1, "");
			}
			
			if (m_n_plus_el == 1)
			{
				m_p_grid.GridCellMerge(m_grid_motor_info, 1, 4, 1, 3);
				m_p_grid.GridCellFont(m_grid_motor_info, 1, 4, "MS Sans Serif", 12);
				m_p_grid.GridCellColor(m_grid_motor_info, 1, 4, BLUE_D, WHITE_C);
				m_p_grid.GridCellText(m_grid_motor_info, 1, 4, "�� PL");
				
				m_p_grid.GridCellMerge(m_grid_motor_info, 2, 4, 1, 3);
				m_p_grid.GridCellFont(m_grid_motor_info, 2, 4, "MS Sans Serif", 12);
				m_p_grid.GridCellColor(m_grid_motor_info, 2, 4, BLACK_L, WHITE_C);
				m_p_grid.GridCellText(m_grid_motor_info, 2, 4, "");
			}
		}
	}
	else
	{
		if (m_n_minus_el == 1)
		{
			m_p_grid.GridCellMerge(m_grid_motor_info, 1, 1, 1, 2);
			m_p_grid.GridCellFont(m_grid_motor_info, 1, 1, "MS Sans Serif", 12);
			m_p_grid.GridCellColor(m_grid_motor_info, 1, 1, BLUE_D, WHITE_C);
			m_p_grid.GridCellText(m_grid_motor_info, 1, 1, "�� ML");
			
			m_p_grid.GridCellMerge(m_grid_motor_info, 2, 1, 1, 2);
			m_p_grid.GridCellFont(m_grid_motor_info, 2, 1, "MS Sans Serif", 12);
			m_p_grid.GridCellColor(m_grid_motor_info, 2, 1, BLACK_L, WHITE_C);
			m_p_grid.GridCellText(m_grid_motor_info, 2, 1, "");
		}
		
		m_p_grid.GridCellMerge(m_grid_motor_info, 1, 3, 1, 2);
		m_p_grid.GridCellFont(m_grid_motor_info, 1, 3, "MS Sans Serif", 12);
		m_p_grid.GridCellColor(m_grid_motor_info, 1, 3, BLUE_D, WHITE_C);
		m_p_grid.GridCellText(m_grid_motor_info, 1, 3, "HOME");
		
		m_p_grid.GridCellMerge(m_grid_motor_info, 2, 3, 1, 2);
		m_p_grid.GridCellFont(m_grid_motor_info, 2, 3, "MS Sans Serif", 12);
		m_p_grid.GridCellColor(m_grid_motor_info, 2, 3, BLACK_L, WHITE_C);
		m_p_grid.GridCellText(m_grid_motor_info, 2, 3, "");

		if (m_n_plus_el == 1)
		{
			m_p_grid.GridCellMerge(m_grid_motor_info, 1, 5, 1, 2);
			m_p_grid.GridCellFont(m_grid_motor_info, 1, 5, "MS Sans Serif", 12);
			m_p_grid.GridCellColor(m_grid_motor_info, 1, 5, BLUE_D, WHITE_C);
			m_p_grid.GridCellText(m_grid_motor_info, 1, 5, "�� PL");
			
			m_p_grid.GridCellMerge(m_grid_motor_info, 2, 5, 1, 2);
			m_p_grid.GridCellFont(m_grid_motor_info, 2, 5, "MS Sans Serif", 12);
			m_p_grid.GridCellColor(m_grid_motor_info, 2, 5, BLACK_L, WHITE_C);
			m_p_grid.GridCellText(m_grid_motor_info, 2, 5, "");
		}
	}

	m_p_grid.GridCellMerge(m_grid_motor_info, 3, 1, 1, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 3, 1, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 3, 1, BLUE_D, WHITE_C);
	m_p_grid.GridCellText(m_grid_motor_info, 3, 1, "Motor Power");
	
	m_p_grid.GridCellMerge(m_grid_motor_info, 4, 1, 1, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 4, 1, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 4, 1, BLACK_L, WHITE_C);
	m_p_grid.GridCellText(m_grid_motor_info, 4, 1, "");

	m_p_grid.GridCellMerge(m_grid_motor_info, 3, 3, 2, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 3, 3, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 3, 3, TEXT_BC, RED_C);
	m_p_grid.GridCellText(m_grid_motor_info, 3, 3, "Power Off");

	m_p_grid.GridCellMerge(m_grid_motor_info, 3, 5, 2, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 3, 5, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 3, 5, TEXT_BC, RED_C);
	m_p_grid.GridCellText(m_grid_motor_info, 3, 5, "Power On");


	m_p_grid.GridCellMerge(m_grid_motor_info, 5, 1, 1, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 5, 1, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 5, 1, BLUE_D, WHITE_C);
	m_p_grid.GridCellText(m_grid_motor_info, 5, 1, "Motor Alarm");
	
	m_p_grid.GridCellMerge(m_grid_motor_info, 6, 1, 1, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 6, 1, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 6, 1, BLACK_L, WHITE_C);
	m_p_grid.GridCellText(m_grid_motor_info, 6, 1, "");

	m_p_grid.GridCellMerge(m_grid_motor_info, 5, 3, 2, 4);
	m_p_grid.GridCellFont(m_grid_motor_info, 5, 3, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 5, 3, TEXT_BC, RED_C);
	m_p_grid.GridCellText(m_grid_motor_info, 5, 3, "Alarm Reset");

	m_p_grid.GridCellMerge(m_grid_motor_info, 7, 1, 1, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 7, 1, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 7, 1, BLUE_D, WHITE_C);
	m_p_grid.GridCellText(m_grid_motor_info, 7, 1, "Motor Move");
	
	m_p_grid.GridCellFont(m_grid_motor_info, 8, 1, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 8, 1, RED_C, BLACK_C);
	m_p_grid.GridCellText(m_grid_motor_info, 8, 1, "Jog");

	m_p_grid.GridCellFont(m_grid_motor_info, 8, 2, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 8, 2, BLACK_L, YELLOW_C);
	m_p_grid.GridCellText(m_grid_motor_info, 8, 2, "Distance");

	m_p_grid.GridCellMerge(m_grid_motor_info, 7, 3, 1, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 7, 3, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 7, 3, BLUE_D, WHITE_C);
	m_p_grid.GridCellText(m_grid_motor_info, 7, 3, "Current Position");
	
	m_p_grid.GridCellMerge(m_grid_motor_info, 8, 3, 1, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 8, 3, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 8, 3, WHITE_C, BLACK_C);
	m_p_grid.GridCellText(m_grid_motor_info, 8, 3, "0");

	m_p_grid.GridCellMerge(m_grid_motor_info, 7, 5, 1, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 7, 5, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 7, 5, BLUE_D, WHITE_C);
	m_p_grid.GridCellText(m_grid_motor_info, 7, 5, "Move Distance (mm)");
	
	m_p_grid.GridCellMerge(m_grid_motor_info, 8, 5, 1, 2);
	m_p_grid.GridCellFont(m_grid_motor_info, 8, 5, "MS Sans Serif", 12);
	m_p_grid.GridCellColor(m_grid_motor_info, 8, 5, WHITE_C, BLACK_C);
	str_tmp.Format("%.2f", m_d_data);
	m_p_grid.GridCellText(m_grid_motor_info, 8, 5, str_tmp);
}
////////////////////////////////////////////////////

void CDialog_Manual_Module::Init_GroupBox_Set()
{
	CSxLogFont ls_Logo(15,FW_SEMIBOLD,false,"���� ����");

	m_group_buffer_rbt_move.SetFont(ls_Logo);;
	m_group_buffer_rbt_move.SetCatptionTextColor(RGB(145,25,0));
	m_group_buffer_rbt_move.SetFontBold(TRUE);

	m_group_buffer.SetFont(ls_Logo);
	m_group_buffer.SetCatptionTextColor(RGB(145,25,0));
	m_group_buffer.SetFontBold(TRUE);

	m_group_tray_pos_clamp_guide.SetFont(ls_Logo);
	m_group_tray_pos_clamp_guide.SetCatptionTextColor(RGB(145,25,0));
	m_group_tray_pos_clamp_guide.SetFontBold(TRUE);

	m_group_step_rbt_move.SetFont(ls_Logo);
	m_group_step_rbt_move.SetCatptionTextColor(RGB(145,25,0));
	m_group_step_rbt_move.SetFontBold(TRUE);

	m_group_picker_rbt_move.SetFont(ls_Logo);
	m_group_picker_rbt_move.SetCatptionTextColor(RGB(145,25,0));
	m_group_picker_rbt_move.SetFontBold(TRUE);

	m_group_picker.SetFont(ls_Logo);
	m_group_picker.SetCatptionTextColor(RGB(145,25,0));
	m_group_picker.SetFontBold(TRUE);

	m_group_motor.SetFont(ls_Logo);
	m_group_motor.SetCatptionTextColor(RGB(145,25,0));
	m_group_motor.SetFontBold(TRUE);

	m_group_motormove.SetFont(ls_Logo);
	m_group_motormove.SetCatptionTextColor(RGB(145,25,0));
	m_group_motormove.SetFontBold(TRUE);

	m_group_cylinder.SetFont(ls_Logo);
	m_group_cylinder.SetCatptionTextColor(RGB(145,25,0));
	m_group_cylinder.SetFontBold(TRUE);


}

void CDialog_Manual_Module::Init_Label()
{
	int i;
	CString str_line;
	
	m_cmb_tray_pos.SetFont(m_load_combo_font);
	m_cmb_tray_pos.PostMessage(CB_SETITEMHEIGHT, (WPARAM)-1, (LPARAM) 60);
	
	for (i = 0; i < st_traybuffer[LDMODULE_SITE].i_loader_row; i++)
	{
		str_line.Format("%02d", i + 1);		
		m_cmb_tray_pos.AddString(str_line);
	}
	m_cmb_tray_pos.SetCurSel(0);


	m_cmb_buffer_pos.SetFont(m_load_combo_font);
	m_cmb_buffer_pos.PostMessage(CB_SETITEMHEIGHT, (WPARAM)-1, (LPARAM) 60);
	
	for (i = 0; i < 4; i++)
	{
		str_line.Format("%02d", i + 1);		
		m_cmb_buffer_pos.AddString(str_line);
	}
	m_cmb_buffer_pos.SetCurSel(0);

	m_cmb_motor_pos.SetFont(m_p_font);
	m_cmb_motor_pos.PostMessage(CB_SETITEMHEIGHT, (WPARAM)-1, (LPARAM) 20);
	
	for (i = 0; i < 9; i++)
	{
		if(i == 0)
		{
			str_line.Format("%02d_MODULE_Y", i + 1);
		}
		else if(i == 1)
		{
			str_line.Format("%02d_MODULE_Z", i + 1);
		}
		else if(i == 2)
		{
			str_line.Format("%02d_STACKER1", i + 1);
		}
		else if(i == 3)
		{
			str_line.Format("%02d_STACKER2", i + 1);
		}
		else if(i == 4)
		{
			str_line.Format("%02d_STACKER_MOVE", i + 1);
		}
		else
		{
			str_line.Format("BUFFER_%02d", i - 4);
		}
		m_cmb_motor_pos.AddString(str_line);
	}

	m_cmb_motor_pos.SetCurSel(0);


	m_cmb_module_pos.SetFont(m_p_font);
	m_cmb_module_pos.PostMessage(CB_SETITEMHEIGHT, (WPARAM)-1, (LPARAM) 20);
	
	for (i = 0; i < 29; i++)
	{
		if(i == 0)
		{
			str_line.Format("Y_Safety");
		}
		else if(i == 1)
		{
			str_line.Format("Y_Tray Start");
		}
		else if(i == 2)
		{
			str_line.Format("Y_Tray End");
		}
		else if(i == 3 || i == 4 || i == 5 || i == 6)
		{
			str_line.Format("Y_WB%01d", i - 2);				
		}
		else if(i == 7)
		{
			str_line.Format("Z_Safety");
		}
		else if(i == 8)
		{
			str_line.Format("Z_Tray Pick");
		}
		else if(i == 9 || i == 10 || i == 11 || i == 12)
		{
			str_line.Format("Z_WB%01d", i - 8);				
		}		
		else if(i == 13)
		{
			str_line.Format("Z_PCB Direction");
		}
		else if(i == 14)
		{
			str_line.Format("Stacker1_Safety");
		}
		else if(i == 15)
		{
			str_line.Format("Stacker1_Down Pos");
		}
		else if(i == 16)
		{
			str_line.Format("Stacker1_Up Pos");
		}
		else if(i == 17)
		{
			str_line.Format("Stacker1_Up Offset");
		}
		else if(i == 18)
		{
			str_line.Format("Stacker1_Down Offset");
		}
		else if(i == 19)
		{
			str_line.Format("Stacker1_P Limit");
		}
		else if(i == 20)
		{
			str_line.Format("Stacker2_Safety");
		}
		else if(i == 21)
		{
			str_line.Format("Stacker2_Down Pos");
		}
		else if(i == 22)
		{
			str_line.Format("Stacker2_Up Pos");
		}
		else if(i == 23)
		{
			str_line.Format("Stacker2_Up Offset");
		}
		else if(i == 24)
		{
			str_line.Format("Stacker2_Down Offset");
		}
		else if(i == 25)
		{
			str_line.Format("Stacker2_P Limit");
		}
		else if(i == 26)
		{
			str_line.Format("Stacker_Move_Safety");
		}
		else if(i == 27)
		{
			str_line.Format("Stacker_Move_Load Pos");
		}
		else if(i == 28)
		{
			str_line.Format("Stacker_Move_Unload Pos");
		}

		m_cmb_module_pos.AddString(str_line);
	}

	m_cmb_module_pos.SetCurSel(0);


	m_msg_picker_sol.SetFont(m_p_font);
	m_msg_picker_sol.SetWindowText(_T("Picker sol"));
	m_msg_picker_sol.SetCenterText();
	m_msg_picker_sol.SetColor(RGB(0,0,255));
	m_msg_picker_sol.SetGradientColor(RGB(0,0,0));
	m_msg_picker_sol.SetTextColor(RGB(255,255,255));

	m_msg_finger_sol.SetFont(m_p_font);
	m_msg_finger_sol.SetWindowText(_T("Finger sol"));
	m_msg_finger_sol.SetCenterText();
	m_msg_finger_sol.SetColor(RGB(0,0,255));
	m_msg_finger_sol.SetGradientColor(RGB(0,0,0));
	m_msg_finger_sol.SetTextColor(RGB(255,255,255));

	m_msg_picker1.SetFont(m_p_font);
	m_msg_picker1.SetWindowText(_T("#1"));
	m_msg_picker1.SetCenterText();
	m_msg_picker1.SetColor(RGB(0,0,255));
	m_msg_picker1.SetGradientColor(RGB(0,0,0));
	m_msg_picker1.SetTextColor(RGB(255,255,255));

	m_msg_picker2.SetFont(m_p_font);
	m_msg_picker2.SetWindowText(_T("#2"));
	m_msg_picker2.SetCenterText();
	m_msg_picker2.SetColor(RGB(0,0,255));
	m_msg_picker2.SetGradientColor(RGB(0,0,0));
	m_msg_picker2.SetTextColor(RGB(255,255,255));

	m_msg_buffer_module.SetFont(m_p_font);
	m_msg_buffer_module.SetWindowText(_T("module sol"));
	m_msg_buffer_module.SetCenterText();
	m_msg_buffer_module.SetColor(RGB(0,0,255));
	m_msg_buffer_module.SetGradientColor(RGB(0,0,0));
	m_msg_buffer_module.SetTextColor(RGB(255,255,255));

	m_msg_buffer1.SetFont(m_p_font);
	m_msg_buffer1.SetWindowText(_T("buffer#1"));
	m_msg_buffer1.SetCenterText();
	m_msg_buffer1.SetColor(RGB(0,0,255));
	m_msg_buffer1.SetGradientColor(RGB(0,0,0));
	m_msg_buffer1.SetTextColor(RGB(255,255,255));

	m_msg_buffer2.SetFont(m_p_font);
	m_msg_buffer2.SetWindowText(_T("buffer#2"));
	m_msg_buffer2.SetCenterText();
	m_msg_buffer2.SetColor(RGB(0,0,255));
	m_msg_buffer2.SetGradientColor(RGB(0,0,0));
	m_msg_buffer2.SetTextColor(RGB(255,255,255));

	m_msg_buffer3.SetFont(m_p_font);
	m_msg_buffer3.SetWindowText(_T("buffer#3"));
	m_msg_buffer3.SetCenterText();
	m_msg_buffer3.SetColor(RGB(0,0,255));
	m_msg_buffer3.SetGradientColor(RGB(0,0,0));
	m_msg_buffer3.SetTextColor(RGB(255,255,255));

	m_msg_buffer4.SetFont(m_p_font);
	m_msg_buffer4.SetWindowText(_T("buffer#4"));
	m_msg_buffer4.SetCenterText();
	m_msg_buffer4.SetColor(RGB(0,0,255));
	m_msg_buffer4.SetGradientColor(RGB(0,0,0));
	m_msg_buffer4.SetTextColor(RGB(255,255,255));

	m_msg_cylinder_sol.SetFont(m_p_font);
	m_msg_cylinder_sol.SetWindowText(_T("cylinder Up/Down"));
	m_msg_cylinder_sol.SetCenterText();
	m_msg_cylinder_sol.SetColor(RGB(0,0,255));
	m_msg_cylinder_sol.SetGradientColor(RGB(0,0,0));
	m_msg_cylinder_sol.SetTextColor(RGB(255,255,255));

}

void CDialog_Manual_Module::Init_Data()
{
 	int i;

	mn_cmd_no = 0;
	mn_motor_no = 0;
	md_mot_start_pos = 0;
	mn_io_clamp1_onoff = 0;
	mn_io_clamp2_onoff = 0;
	mn_io_guide2_onoff = 0;

	for (i = 0; i < 2; i++)
	{
		mn_picker[i] = 0;
		mn_finger[i] = 0;
		mn_cylinder[i] = 0;
		mn_module_buffer[i] = 0;
		mn_module_buffer[i + 2] = 0;
	}

//////////////////////////////////////////////////// 20121006
	m_n_axis			= st_motor_info.n_part_axis[0][AXIS_NUM];
	
	m_str_axis_name = st_motor_info.str_part_axis_name[0][AXIS_NUM];
	m_n_minus_el	= st_motor_info.n_axis_minus_el[0][AXIS_NUM];
	m_n_plus_el		= st_motor_info.n_axis_plus_el[0][AXIS_NUM];
	m_n_home		= st_motor_info.n_axis_home[0][AXIS_NUM];
	m_n_sd			= st_motor_info.n_axis_sd[0][AXIS_NUM];
	m_n_direction	= st_motor_info.n_axis_direction[0][AXIS_NUM];
	m_n_account		= st_motor_info.n_axis_account[0][AXIS_NUM];


////////////////////////////////////////////////////	
}

void CDialog_Manual_Module::Init_Button()
{
	short	shBtnColor = 30;
	CString strTmp;
	int nMotorPos = m_cmb_motor_pos.GetCurSel();

	if(nMotorPos == 0 || nMotorPos == 2 || nMotorPos == 3 || nMotorPos == 4)
	{
		m_btn_left.SetIcon(IDI_DN);
	}
	else if(nMotorPos == 1)
	{
		m_btn_left.SetIcon(IDI_UP);
	}
	else
	{
		m_btn_left.SetIcon(IDI_LEFT);
	}	

//	m_btn_left.SetIcon(IDI_DN);
	m_btn_left.SetTag(IDC_BTN_LEFT);
	m_btn_left.SetFont(m_p_font);
	m_btn_left.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_left.SetButtonColor(1);

	if(nMotorPos == 0 || nMotorPos == 2 || nMotorPos == 3 || nMotorPos == 4)
	{
		m_btn_right.SetIcon(IDI_UP);
	}
	else if(nMotorPos == 1)
	{
		m_btn_right.SetIcon(IDI_DN);
	}
	else
	{
		m_btn_right.SetIcon(IDI_RIGHT);
	}	
	
//	m_btn_right.SetIcon(IDI_UP);
	m_btn_right.SetTag(IDC_BTN_RIGHT);
	m_btn_right.SetFont(m_p_font);
	m_btn_right.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_right.SetButtonColor(1);
	
	m_btn_home.SetTag(IDC_BTN_HOME);
	m_btn_home.SetFont(m_p_font);
	m_btn_home.SetIcon(IDI_HOME);
	m_btn_home.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_home.SetButtonColor(1);
	
	m_btn_picker_sol1.SetFont(m_p_font);
	m_btn_picker_sol1.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
	m_btn_picker_sol1.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_picker_sol1.SetButtonColor(1);
	
	m_btn_picker_sol2.SetFont(m_p_font);
	m_btn_picker_sol2.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
	m_btn_picker_sol2.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_picker_sol2.SetButtonColor(1);
	
	m_btn_finger_sol1.SetFont(m_p_font);
	m_btn_finger_sol1.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
	m_btn_finger_sol1.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_finger_sol1.SetButtonColor(1);
	
	m_btn_finger_sol2.SetFont(m_p_font);
	m_btn_finger_sol2.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
	m_btn_finger_sol2.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_finger_sol2.SetButtonColor(1);
	
	m_btn_buffer_module_sol1.SetFont(m_p_font);
	m_btn_buffer_module_sol1.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
	m_btn_buffer_module_sol1.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_buffer_module_sol1.SetButtonColor(1);
	
	m_btn_buffer_module_sol2.SetFont(m_p_font);
	m_btn_buffer_module_sol2.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
	m_btn_buffer_module_sol2.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_buffer_module_sol2.SetButtonColor(1);
	
	m_btn_buffer_module_sol3.SetFont(m_p_font);
	m_btn_buffer_module_sol3.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
	m_btn_buffer_module_sol3.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_buffer_module_sol3.SetButtonColor(1);
	
	m_btn_buffer_module_sol4.SetFont(m_p_font);
	m_btn_buffer_module_sol4.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
	m_btn_buffer_module_sol4.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_buffer_module_sol4.SetButtonColor(1);
	
	m_btn_cylinder_sol.SetFont(m_p_font);
	m_btn_cylinder_sol.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
	m_btn_cylinder_sol.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
	m_btn_cylinder_sol.SetButtonColor(1);

}

void CDialog_Manual_Module::OnBtnCylinderSol() 
{
	// TODO: Add your control notification handler code here
	if (m_btn_cylinder_sol.GetCheck() == 1)
	{
		FAS_IO.set_out_bit(st_io.o_m_stacker2_up_onoff, IO_ON);
		FAS_IO.set_out_bit(st_io.o_m_stacker2_dn_onoff, IO_OFF);
		mn_cylinder[0] = TRUE;
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_m_stacker2_up_onoff, IO_OFF);
		FAS_IO.set_out_bit(st_io.o_m_stacker2_dn_onoff, IO_ON);
		mn_cylinder[0] = FALSE;
	}	
	OnSiteRbt_Button_Status();	
	
}

void CDialog_Manual_Module::OnBtnPickerSol1() 
{
	if (m_btn_picker_sol1.GetCheck() == 1)
	{
		FAS_IO.set_out_bit(st_io.o_ld_module_picker_updn[0], IO_ON);
		mn_picker[0] = TRUE;
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_ld_module_picker_updn[0], IO_OFF);
		mn_picker[0] = FALSE;
	}	
	OnSiteRbt_Button_Status();	
}

void CDialog_Manual_Module::OnBtnPickerSol2() 
{
	if (m_btn_picker_sol2.GetCheck() == 1)
	{
		FAS_IO.set_out_bit(st_io.o_ld_module_picker_updn[1], IO_ON);
		mn_picker[1] = TRUE;
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_ld_module_picker_updn[1], IO_OFF);
		mn_picker[1] = FALSE;
	}	
	OnSiteRbt_Button_Status();		
}

void CDialog_Manual_Module::OnBtnPickerSolAll() 
{
	int i;
	if (m_btn_picker_sol_all.GetCheck() == 0)//1�� ����
	{
		for (i = 0; i < PICKER_NUM; i++)
		{
			FAS_IO.set_out_bit(st_io.o_ld_module_picker_updn[i], IO_OFF); 
			mn_picker[i] = FALSE;
		}		
	}
	else
	{
		for (i = 0; i < PICKER_NUM; i++)
		{
			FAS_IO.set_out_bit(st_io.o_ld_module_picker_updn[i], IO_ON); 
			mn_picker[i] = TRUE;
		}		
	}
	
	OnSiteRbt_Button_Status();
}

void CDialog_Manual_Module::OnBtnFingerSol1() 
{
	if (m_btn_finger_sol1.GetCheck() == 1)
	{
		FAS_IO.set_out_bit(st_io.o_ld_module_glipper_onoff[0], IO_ON);
		mn_finger[0] = TRUE;
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_ld_module_glipper_onoff[0], IO_OFF);
		mn_finger[0] = FALSE;
	}	
	OnSiteRbt_Button_Status();			
}

void CDialog_Manual_Module::OnBtnFingerSol2() 
{
	if (m_btn_finger_sol2.GetCheck() == 1)
	{
		FAS_IO.set_out_bit(st_io.o_ld_module_glipper_onoff[1], IO_ON);
		mn_finger[1] = TRUE;
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_ld_module_glipper_onoff[1], IO_OFF);
		mn_finger[1] = FALSE;
	}	
	OnSiteRbt_Button_Status();		
}

void CDialog_Manual_Module::OnBtnFingerSolAll() 
{
	int i;
	if (m_btn_finger_sol_all.GetCheck() == 0)//1�� ����
	{
		for (i = 0; i < PICKER_NUM; i++)
		{
			FAS_IO.set_out_bit(st_io.o_ld_module_glipper_onoff[i], IO_OFF); 
			mn_finger[i] = FALSE;
		}		
	}
	else
	{
		for (i = 0; i < PICKER_NUM; i++)
		{
			FAS_IO.set_out_bit(st_io.o_ld_module_glipper_onoff[i], IO_ON); 
			mn_finger[i] = TRUE;
		}		
	}
	
	OnSiteRbt_Button_Status();	
}

void CDialog_Manual_Module::OnBtnBufferModuleSol1() 
{
	if (m_btn_buffer_module_sol1.GetCheck() == 1)
	{
		FAS_IO.set_out_bit(st_io.o_buf1_m_clamp_onoff, IO_ON);
		mn_module_buffer[0] = TRUE;
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_buf1_m_clamp_onoff, IO_OFF);
		mn_module_buffer[0] = FALSE;
	}	
	OnSiteRbt_Button_Status();
}

void CDialog_Manual_Module::OnBtnBufferModuleSol2() 
{
	if (m_btn_buffer_module_sol2.GetCheck() == 1)
	{
		FAS_IO.set_out_bit(st_io.o_buf2_m_clamp_onoff, IO_ON);
		mn_module_buffer[1] = TRUE;
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_buf2_m_clamp_onoff, IO_OFF);
		mn_module_buffer[1] = FALSE;
	}	
	OnSiteRbt_Button_Status();	
}

void CDialog_Manual_Module::OnBtnBufferModuleSol3() 
{
	if (m_btn_buffer_module_sol3.GetCheck() == 1)
	{
		FAS_IO.set_out_bit(st_io.o_buf3_m_clamp_onoff, IO_ON);
		mn_module_buffer[2] = TRUE;
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_buf3_m_clamp_onoff, IO_OFF);
		mn_module_buffer[2] = FALSE;
	}	
	OnSiteRbt_Button_Status();	
}

void CDialog_Manual_Module::OnBtnBufferModuleSol4() 
{
	if (m_btn_buffer_module_sol4.GetCheck() == 1)
	{
		FAS_IO.set_out_bit(st_io.o_buf4_m_clamp_onoff, IO_ON);
		mn_module_buffer[3] = TRUE;
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_buf4_m_clamp_onoff, IO_OFF);
		mn_module_buffer[3] = FALSE;
	}	
	OnSiteRbt_Button_Status();	
}

void CDialog_Manual_Module::OnRead_IO_Check()
{
	int i;

	if(FAS_IO.get_in_bit(st_io.o_m_stacker2_up_onoff, IO_ON) == IO_ON && 
		FAS_IO.get_in_bit(st_io.o_m_stacker2_dn_onoff, IO_OFF) == IO_OFF)
	{
		mn_cylinder[0] = TRUE;
	}
	else
	{
		mn_cylinder[0] = FALSE;		
	}

	for(i=0; i<2; i++)
	{
		if(FAS_IO.get_in_bit(st_io.o_ld_module_picker_updn[i], IO_ON) == IO_ON)
		{
			mn_picker[i] = TRUE;
		}
		else
		{
			mn_picker[i] = FALSE;		
		}	
	}

	for(i=0; i<2; i++)
	{
		if(FAS_IO.get_in_bit(st_io.o_ld_module_glipper_onoff[i], IO_ON) == IO_ON)
		{
			mn_finger[i] = TRUE;
		}
		else
		{
			mn_finger[i] = FALSE;		
		}	
	}

	for(i=0; i<4; i++)
	{
		if(FAS_IO.get_in_bit(st_io.o_buf1_m_clamp_onoff + (i*100), IO_ON) == IO_ON)
		{
			mn_module_buffer[i] = TRUE;
		}
		else
		{
			mn_module_buffer[i] = FALSE;		
		}	
	}

}

void CDialog_Manual_Module::OnSiteRbt_Button_Status()//20121006
{
	short	shBtnColor = 30;
	
	if (mn_cylinder[0] < 0 || mn_cylinder[0] > 1) mn_cylinder[0] = TRUE;
	m_btn_cylinder_sol.SetCheck(mn_cylinder[0]);
	if (mn_cylinder[0] == TRUE)
	{
		m_btn_cylinder_sol.SetCheck(TRUE);
		SetDlgItemText(IDC_BTN_CYLINDER_SOL, "Down");
		m_btn_cylinder_sol.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_cylinder_sol.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_cylinder_sol.SetButtonColor(1);
	}
	else																					// Off���̸�
	{
		m_btn_cylinder_sol.SetCheck(FALSE);
		SetDlgItemText(IDC_BTN_CYLINDER_SOL, "Up");
		m_btn_cylinder_sol.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_cylinder_sol.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_cylinder_sol.SetButtonColor(1);

	}

	if (mn_picker[0] < 0 || mn_picker[0] > 1) mn_picker[0] = TRUE;
	m_btn_picker_sol1.SetCheck(mn_picker[0]);
	if (mn_picker[0] == TRUE)
	{
		m_btn_picker_sol1.SetCheck(TRUE);
		SetDlgItemText(IDC_BTN_PICKER_SOL_1, "Up");
		m_btn_picker_sol1.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_picker_sol1.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_picker_sol1.SetButtonColor(1);
	}
	else																					// Off���̸�
	{
		m_btn_picker_sol1.SetCheck(FALSE);
		SetDlgItemText(IDC_BTN_PICKER_SOL_1, "Down");
		m_btn_picker_sol1.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_picker_sol1.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_picker_sol1.SetButtonColor(1);

	}

	if (mn_picker[1] < 0 || mn_picker[1] > 1) mn_picker[1] = TRUE;
	m_btn_picker_sol2.SetCheck(mn_picker[1]);
	if (mn_picker[1] == TRUE)
	{
		m_btn_picker_sol2.SetCheck(TRUE);
		SetDlgItemText(IDC_BTN_PICKER_SOL_2, "Up");
		m_btn_picker_sol2.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_picker_sol2.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_picker_sol2.SetButtonColor(1);
	}
	else																					// Off���̸�
	{
		m_btn_picker_sol2.SetCheck(FALSE);
		SetDlgItemText(IDC_BTN_PICKER_SOL_2, "Down");
		m_btn_picker_sol2.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_picker_sol2.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_picker_sol2.SetButtonColor(1);

	}

	if (mn_finger[0] < 0 || mn_finger[0] > 1) mn_finger[0] = TRUE;
	m_btn_finger_sol1.SetCheck(mn_finger[0]);
	if (mn_finger[0] == TRUE)
	{
		m_btn_finger_sol1.SetCheck(TRUE);
		SetDlgItemText(IDC_BTN_FINGER_SOL_1, "On");
		m_btn_finger_sol1.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_finger_sol1.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_finger_sol1.SetButtonColor(1);

	}	
	else
	{
		m_btn_finger_sol1.SetCheck(FALSE);
		SetDlgItemText(IDC_BTN_FINGER_SOL_1, "Off");
		m_btn_finger_sol1.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_finger_sol1.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_finger_sol1.SetButtonColor(1);

	}

	if (mn_finger[1] < 0 || mn_finger[1] > 1) mn_finger[1] = TRUE;
	m_btn_finger_sol2.SetCheck(mn_finger[1]);
	if (mn_finger[1] == TRUE)
	{
		m_btn_finger_sol2.SetCheck(TRUE);
		SetDlgItemText(IDC_BTN_FINGER_SOL_2, "On");
		m_btn_finger_sol2.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_finger_sol2.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_finger_sol2.SetButtonColor(1);
	}	
	else
	{
		m_btn_finger_sol2.SetCheck(FALSE);
		SetDlgItemText(IDC_BTN_FINGER_SOL_2, "Off");
		m_btn_finger_sol2.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_finger_sol2.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_finger_sol2.SetButtonColor(1);
	}

	if (mn_module_buffer[0] < 0 || mn_module_buffer[0] > 1) mn_module_buffer[0] = TRUE;
	m_btn_buffer_module_sol1.SetCheck(mn_module_buffer[0]);
	if (mn_module_buffer[0] == TRUE)
	{
		m_btn_buffer_module_sol1.SetCheck(TRUE);
		SetDlgItemText(IDC_BTN_BUFFER_MODULE_SOL1, "On");
		m_btn_buffer_module_sol1.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_buffer_module_sol1.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_buffer_module_sol1.SetButtonColor(1);

	}
	else
	{
		m_btn_buffer_module_sol1.SetCheck(FALSE);
		SetDlgItemText(IDC_BTN_BUFFER_MODULE_SOL1, "Off");
		m_btn_buffer_module_sol1.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_buffer_module_sol1.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_buffer_module_sol1.SetButtonColor(1);

	}

	if (mn_module_buffer[1] < 0 || mn_module_buffer[1] > 1) mn_module_buffer[1] = TRUE;
	m_btn_buffer_module_sol2.SetCheck(mn_module_buffer[1]);
	if (mn_module_buffer[1] == TRUE)
	{
		m_btn_buffer_module_sol2.SetCheck(TRUE);
		SetDlgItemText(IDC_BTN_BUFFER_MODULE_SOL2, "On");
		m_btn_buffer_module_sol2.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_buffer_module_sol2.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_buffer_module_sol2.SetButtonColor(1);

	}
	else
	{
		m_btn_buffer_module_sol2.SetCheck(FALSE);
		SetDlgItemText(IDC_BTN_BUFFER_MODULE_SOL2, "Off");
		m_btn_buffer_module_sol2.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_buffer_module_sol2.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_buffer_module_sol2.SetButtonColor(1);

	}

	if (mn_module_buffer[2] < 0 || mn_module_buffer[2] > 1) mn_module_buffer[2] = TRUE;
	m_btn_buffer_module_sol3.SetCheck(mn_module_buffer[2]);
	if (mn_module_buffer[2] == TRUE)
	{
		m_btn_buffer_module_sol3.SetCheck(TRUE);
		SetDlgItemText(IDC_BTN_BUFFER_MODULE_SOL3, "On");
		m_btn_buffer_module_sol3.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_buffer_module_sol3.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_buffer_module_sol3.SetButtonColor(1);

	}
	else
	{
		m_btn_buffer_module_sol3.SetCheck(FALSE);
		SetDlgItemText(IDC_BTN_BUFFER_MODULE_SOL3, "Off");
		m_btn_buffer_module_sol3.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_buffer_module_sol3.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_buffer_module_sol3.SetButtonColor(1);

	}

	if (mn_module_buffer[3] < 0 || mn_module_buffer[3] > 1) mn_module_buffer[3] = TRUE;
	m_btn_buffer_module_sol4.SetCheck(mn_module_buffer[3]);
	if (mn_module_buffer[3] == TRUE)
	{
		m_btn_buffer_module_sol4.SetCheck(TRUE);
		SetDlgItemText(IDC_BTN_BUFFER_MODULE_SOL4, "On");
		m_btn_buffer_module_sol4.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_buffer_module_sol4.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_buffer_module_sol4.SetButtonColor(1);

	}
	else
	{
		m_btn_buffer_module_sol4.SetCheck(FALSE);
		SetDlgItemText(IDC_BTN_BUFFER_MODULE_SOL4, "Off");
		m_btn_buffer_module_sol4.SetIcon(IDI_GREEN_LED_ICON, IDI_RED_LED_ICON);
		m_btn_buffer_module_sol4.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, shBtnColor);
		m_btn_buffer_module_sol4.SetButtonColor(1);

	}
}

void CDialog_Manual_Module::OnSite_Controls_Enable(BOOL iFlag)
{
	m_btn_cylinder_sol.EnableWindow(iFlag);
	m_btn_go_module_pos.EnableWindow(iFlag);
	m_btn_go_buffer_pos.EnableWindow(iFlag);
	m_btn_go_tray_pos.EnableWindow(iFlag);
	m_btn_go_step_rbt_move.EnableWindow(iFlag);
	m_btn_picker_sol1.EnableWindow(iFlag);
	m_btn_picker_sol2.EnableWindow(iFlag);
	m_btn_picker_sol_all.EnableWindow(iFlag);
	m_btn_finger_sol1.EnableWindow(iFlag);
	m_btn_finger_sol2.EnableWindow(iFlag);
	m_btn_finger_sol_all.EnableWindow(iFlag);
	m_btn_clamp1_onoff.EnableWindow(iFlag);
	m_btn_clamp2_onoff.EnableWindow(iFlag);
	m_btn_guide2_onoff.EnableWindow(iFlag);
	m_btn_buffer_module_sol1.EnableWindow(iFlag);
	m_btn_buffer_module_sol2.EnableWindow(iFlag);
	m_btn_buffer_module_sol3.EnableWindow(iFlag);
	m_btn_buffer_module_sol4.EnableWindow(iFlag);
}

void CDialog_Manual_Module::OnSite_Step_Clear()
{
	mn_stop_req = FALSE;  // ESTOP ��û �÷��� �ʱ�ȭ

	mn_cmd_no = 0;        // ���� ���� ��ȣ ���� ���� �ʱ�ȭ

	mn_home_step = 0;     // ���� HOMING ó�� ���� ���� ���� �ʱ�ȭ
	mn_move_step = 0;     // ���� �̵� ó�� ���� ���� ���� �ʱ�ȭ
}

void CDialog_Manual_Module::OnBtnGoTrayPos() 
{
	int x, n_tray_y;
	int mn_FirstPicker_Y_Pos = 0;
	////////////////////// 20121107
	int	nRet;	
	int n_response;	
	CDialog_Message  msg_dlg;
	////////////////////// 
	
	n_tray_y = m_cmb_tray_pos.GetCurSel();
	
	if (n_tray_y < 0)	
	{
		if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
		{
			sprintf(st_msg.c_abnormal_msg,"[Module RBT] can not move.");
			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� �Ϸ� ��� ��û
		}
		return;
	}
	
	OnSite_Controls_Enable(FALSE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
	
	if (st_handler.mn_menu_lock != TRUE)
		st_handler.mn_menu_lock = TRUE;
	// **************************************************************************
	
	OnSite_Step_Clear();				// ���� ���� ó�� ���� �ʱ�ȭ �Լ�
	
	// **************************************************************************
	// ���� �̵� ��ġ �����Ѵ�                                                   
	// **************************************************************************

	////////////////////// 20121107
	nRet = COMI.Check_SingleMove(M_M_RBT_Z, st_motor[M_M_RBT_Z].md_pos[Z_LD_SAFETY_UP]);
	if (nRet != CTLBD_RET_GOOD)
	{
		st_msg.str_fallacy_msg = _T("Z���� Safety ��ġ�� �ƴմϴ�.");	
		if(st_handler.mn_language == LANGUAGE_ENGLISH)
		{
			st_msg.str_fallacy_msg = _T("Safety is not the position of the Z-axis");
		}
		
		n_response = msg_dlg.DoModal();
		OnSite_Controls_Enable(TRUE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
		st_handler.mn_menu_lock = FALSE;
		return;
	}
	else
	{
	}
	//////////////////////

	mn_cmd_no = MOT_MOVE;					// ���� ���� ��ȣ ���� [���� �̵� ����]
	mn_motor_no = M_M_RBT_Y;

	for(x=0 ; x<PICKER_NUM; x++) 
	{
		if(st_modulemap.nModuleRobotPicker[D_EXIST][x] == DVC_NO && st_picker.n_module_ldrbt_enable[x] == YES)
		{
			mn_FirstPicker_Y_Pos = x;
			break;
		}
	}
	md_mot_start_pos = Func.XYRobot_MovePosValCheck(LDMODULE_SITE, 0, mn_FirstPicker_Y_Pos, n_tray_y); // Ʈ���̿��� ã�� ��ġ�� ������ �̵���Ų��
	
	SetTimer(TMR_MODULEMOT_CMD, 10, NULL);		// ���� ���� ���� Ÿ�̸�
	// **************************************************************************	
}

void CDialog_Manual_Module::OnBtnGoBufferPos() 
{
	int n_tray_y;
	int mn_FirstPicker_Y_Pos = 0;
	////////////////////// 20121107
	int	nRet, nRet1, nRet2, nRet3, nRet4;	
	int n_response;	
	CDialog_Message  msg_dlg;
	////////////////////// 
	
	n_tray_y = m_cmb_buffer_pos.GetCurSel();
	
	if (n_tray_y < 0)	
	{
		if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
		{
			sprintf(st_msg.c_abnormal_msg,"[Buffer RBT] can not move.");
			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� �Ϸ� ��� ��û
		}
		return;
	}
	
	OnSite_Controls_Enable(FALSE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
	
	if (st_handler.mn_menu_lock != TRUE)
		st_handler.mn_menu_lock = TRUE;
	// **************************************************************************
	
	OnSite_Step_Clear();				// ���� ���� ó�� ���� �ʱ�ȭ �Լ�
	
	// **************************************************************************
	// ���� �̵� ��ġ �����Ѵ�                                                   
	// **************************************************************************

	////////////////////// 20121107
	nRet = COMI.Check_SingleMove(M_M_RBT_Z, st_motor[M_M_RBT_Z].md_pos[Z_LD_SAFETY_UP]);
	nRet1 = COMI.Check_SingleMove(M_HS_B_RBT_Z, Z_LD_SAFETY_UP);
	nRet2 = COMI.Check_SingleMove(M_HS_F_RBT_Z, Z_LD_SAFETY_UP);
	nRet3 = COMI.Check_SingleMove(M_M_CLAMP_RBT_Z, st_motor[M_M_CLAMP_RBT_Z].md_pos[Z_LD_SAFETY_UP]);
	nRet4 = COMI.Check_SingleMove(M_RBT_SORTER_Z, Z_SORT_SAFETY_UP);

	if (nRet == CTLBD_RET_GOOD && nRet1 == CTLBD_RET_GOOD && nRet2 == CTLBD_RET_GOOD && 
		nRet3 == CTLBD_RET_GOOD && nRet1 == CTLBD_RET_GOOD)
	{
	}
	else
	{
		st_msg.str_fallacy_msg = _T("��� && Front/Back HS && ��� Clamp && Sorter �κ� Z���� Safety ��ġ�� �ƴմϴ�.");
		if(st_handler.mn_language == LANGUAGE_ENGLISH)
		{
			st_msg.str_fallacy_msg = _T("Modules && Front / Back HS && module Safety Clamp && Sorter Z axis position is not a robot");
		}
		
		n_response = msg_dlg.DoModal();
		OnSite_Controls_Enable(TRUE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
		st_handler.mn_menu_lock = FALSE;
		return;
	}
	//////////////////////

	mn_cmd_no = MOT_MOVE;					// ���� ���� ��ȣ ���� [���� �̵� ����]
	mn_motor_no = M_WORK_BUFFER_1 + n_tray_y;

	md_mot_start_pos = st_motor[mn_motor_no].md_pos[WORK_LDMODULE];
	
	SetTimer(TMR_MODULEMOT_CMD, 10, NULL);		// ���� ���� ���� Ÿ�̸�
	// **************************************************************************		
}

void CDialog_Manual_Module::OnSite_RadioButton_Set()
{
	m_io_clamp1_onoff.SetIcons(IDI_GRAY_LED_ICON, IDI_RED_LED_ICON);
	m_io_clamp2_onoff.SetIcons(IDI_GRAY_LED_ICON, IDI_RED_LED_ICON);
	m_io_guide2_onoff.SetIcons(IDI_GRAY_LED_ICON, IDI_RED_LED_ICON);
}

void CDialog_Manual_Module::OnSite_IO_Status_Read()
{
	if (FAS_IO.get_in_bit(st_io.i_m_stacker1_rail_fwd_chk, IO_ON) == IO_ON && 
		FAS_IO.get_in_bit(st_io.i_m_stacker1_rail_bwd_chk, IO_OFF) == IO_OFF)		mn_io_clamp1_onoff = TRUE;
	else																			mn_io_clamp1_onoff = FALSE;

	if (FAS_IO.get_in_bit(st_io.i_m_stacker2_rail_fwd_chk, IO_ON) == IO_ON && 
		FAS_IO.get_in_bit(st_io.i_m_stacker2_rail_bwd_chk, IO_OFF) == IO_OFF)		mn_io_clamp2_onoff = TRUE;
	else																			mn_io_clamp2_onoff = FALSE;

	if (FAS_IO.get_in_bit(st_io.i_m_stacker2_tray_clamp_on_chk, IO_ON) == IO_ON &&
		FAS_IO.get_in_bit(st_io.i_m_stacker2_tray_clamp_off_chk, IO_OFF) == IO_OFF)	mn_io_guide2_onoff = TRUE;
	else																			mn_io_guide2_onoff = FALSE;

}

void CDialog_Manual_Module::OnSite_IO_Button_Status()
{
	// **************************************************************************
	// IO ���� �Է� ���� ���� ���� ����
	// **************************************************************************
	m_io_clamp1_onoff.SetLedState(mn_io_clamp1_onoff);
	m_io_clamp2_onoff.SetLedState(mn_io_clamp2_onoff);
	m_io_guide2_onoff.SetLedState(mn_io_guide2_onoff);
}

void CDialog_Manual_Module::OnBtnClamp1Onoff() 
{
	int nRet_1;

	nRet_1 = FAS_IO.get_in_bit(st_io.i_m_stacker1_rail_tray_chk, IO_OFF);
	if(nRet_1 == IO_ON && mn_io_clamp1_onoff == TRUE)
	{
		if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
		{
			sprintf(st_msg.c_abnormal_msg,"Stacker1 ���Ͽ� Ʈ���̰� �ֽ��ϴ�.");
			if(st_handler.mn_language == LANGUAGE_ENGLISH) 
			{
				sprintf(st_msg.c_abnormal_msg, "There are rails on tray Stacker1");
			}

			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� �Ϸ� ��� ��û
		}
		return;	
	}
	if(mn_io_clamp1_onoff == TRUE)
	{
		FAS_IO.set_out_bit(st_io.o_m_stacker1_rail_fwd_onoff, IO_OFF);
		FAS_IO.set_out_bit(st_io.o_m_stacker1_rail_bwd_onoff, IO_ON);
		SetDlgItemText(IDC_BTN_CLAMP1_ONOFF, "On");
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_m_stacker1_rail_fwd_onoff, IO_ON);
		FAS_IO.set_out_bit(st_io.o_m_stacker1_rail_bwd_onoff, IO_OFF);
		SetDlgItemText(IDC_BTN_CLAMP1_ONOFF, "Off");
	}
}

void CDialog_Manual_Module::OnBtnClamp2Onoff() 
{
	int nRet_1;

	nRet_1 = FAS_IO.get_in_bit(st_io.i_m_stacker2_rail_tray_chk, IO_OFF);
	if(nRet_1 == IO_ON && mn_io_clamp2_onoff == TRUE)
	{
		if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
		{
			sprintf(st_msg.c_abnormal_msg,"Stacker2 ���Ͽ� Ʈ���̰� �ֽ��ϴ�.");
			if(st_handler.mn_language == LANGUAGE_ENGLISH) 
			{
				sprintf(st_msg.c_abnormal_msg, "There are rails on tray Stacker2");
			}

			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� �Ϸ� ��� ��û
		}
		return;	
	}

	if(mn_io_clamp2_onoff == TRUE)
	{
		FAS_IO.set_out_bit(st_io.o_m_stacker2_rail_fwd_onoff, IO_OFF);
		FAS_IO.set_out_bit(st_io.o_m_stacker2_rail_bwd_onoff, IO_ON);
		SetDlgItemText(IDC_BTN_CLAMP2_ONOFF, "On");
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_m_stacker2_rail_fwd_onoff, IO_ON);
		FAS_IO.set_out_bit(st_io.o_m_stacker2_rail_bwd_onoff, IO_OFF);
		SetDlgItemText(IDC_BTN_CLAMP2_ONOFF, "Off");
	}	
}

void CDialog_Manual_Module::OnBtnGuide2Onff() 
{
	int nRet_1;

	nRet_1 = FAS_IO.get_in_bit(st_io.i_m_stacker2_rail_tray_chk, IO_OFF);
	if(nRet_1 == IO_ON && mn_io_clamp2_onoff == TRUE)
	{
		if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
		{
			sprintf(st_msg.c_abnormal_msg,"Stacker2 ���Ͽ� Ʈ���̰� �ֽ��ϴ�.");
			if(st_handler.mn_language == LANGUAGE_ENGLISH) 
			{
				sprintf(st_msg.c_abnormal_msg, "There are rails on tray Stacker2");
			}

			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� �Ϸ� ��� ��û
		}
		return;	
	}
	if(mn_io_guide2_onoff == TRUE)
	{
		FAS_IO.set_out_bit(st_io.o_m_stacker2_tray_clamp_onoff, IO_OFF);
		SetDlgItemText(IDC_BTN_GUIDE2_ONFF, "On");
	}
	else
	{
		FAS_IO.set_out_bit(st_io.o_m_stacker2_tray_clamp_onoff, IO_ON);
		SetDlgItemText(IDC_BTN_GUIDE2_ONFF, "Off");
	}

}

void CDialog_Manual_Module::OnTimer(UINT nIDEvent) 
{
	int n_response,n_check;
//	int nRet[5];

	CDialog_Message msg_dlg;

	if (nIDEvent == TMR_MODULEMOT_CMD) 
	{
		// **************************************************************************
		// ��� ���� �ʱ�ȭ �۾� �Ϸ� ���� �˻��Ѵ�                                  
		// **************************************************************************
		if (st_handler.mn_mot_brd_initial != TRUE)  
		{
			KillTimer(TMR_MODULEMOT_CMD) ;  // Ÿ�̸� ����
			mn_cmd_no = 0;				// ���� ���� ��ȣ ���� ���� �ʱ�ȭ

			st_other.str_fallacy_msg = _T("Initialize first motion board...error...");
			n_response = msg_dlg.DoModal();

			if (n_response == IDOK) 
			{
				n_check = CTLBD_RET_ERROR;
			}
			else
			{
				n_check = CTLBD_RET_ERROR;
			}
		}
		// **************************************************************************

		if (mn_cmd_no == MOT_HOME)
		{
			n_check = OnSite_Homing_Excution();		// ���� HOMING ó�� �Լ�

			if(n_check == CTLBD_RET_GOOD)
			{
				KillTimer(TMR_MODULEMOT_CMD) ;  // Ÿ�̸� ���� //
				if(st_handler.mn_home_state[mn_motor_no] != TRUE)
				{
					st_handler.mn_home_state[mn_motor_no] = TRUE;
				}				
				mn_cmd_no = 0;  // ���� ���� ��ȣ ���� ���� �ʱ�ȭ //				
				if(st_handler.mn_menu_lock != FALSE)
				{
					st_handler.mn_menu_lock = FALSE;
				}
				// ==============================================================================

				OnSite_Controls_Enable(TRUE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ� //
			}
			else if(n_check == CTLBD_RET_ERROR)
			{
				KillTimer(TMR_MODULEMOT_CMD) ;  // Ÿ�̸� ���� //
				
				mn_cmd_no = 0;  // ���� ���� ��ȣ ���� ���� �ʱ�ȭ //
				
				// ==============================================================================
				// �޴� ��� �����ϵ��� �÷��� �����Ѵ�
				// -> st_handler.i_menu_lock   : �޴� ��� ���� ���� �÷���
				//  : ���� �������� �޴� ��ȯ �κп��� �� �÷��� �˻��ϰ� �ȴ�
				// ==============================================================================
				if(st_handler.mn_menu_lock != FALSE)
				{
					st_handler.mn_menu_lock = FALSE;
				}
				// ==============================================================================
				OnSite_Controls_Enable(TRUE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ� //
			}
		}
		else if (mn_cmd_no == MOT_MOVE)
		{
			n_check = OnSite_Move_Excution();			// ���� �̵� ���� ó�� �Լ�
			if (n_check == CTLBD_RET_GOOD)   
			{
				KillTimer(TMR_MODULEMOT_CMD) ;  // Ÿ�̸� ����
				mn_cmd_no = 0;  // ���� ���� ��ȣ ���� ���� �ʱ�ȭ

				// ******************************************************************
				if (st_handler.mn_menu_lock != FALSE)
					st_handler.mn_menu_lock = FALSE;
				// ******************************************************************

				OnSite_Controls_Enable(TRUE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
			}
			else if (n_check == CTLBD_RET_ERROR) 
			{
				KillTimer(TMR_MODULEMOT_CMD) ;  // Ÿ�̸� ����

				mn_cmd_no = 0;  // ���� ���� ��ȣ ���� ���� �ʱ�ȭ

				if (st_handler.mn_menu_lock != FALSE)
					st_handler.mn_menu_lock = FALSE;
				// ******************************************************************

				OnSite_Controls_Enable(TRUE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
			}	
		}
		else 
		{
			KillTimer(TMR_MODULEMOT_CMD) ;  // Ÿ�̸� ����
		}


	}
	else if (nIDEvent == TMR_IO_MONITOR_CMD) 
	{
		OnSite_IO_Status_Read();
	}
	else if (nIDEvent == TMR_STEPMOT_CMD) 
	{
		Run_Init();
		if (st_handler.mn_init_state[INIT_RBT_MODULE] == CTL_YES)
		{
			KillTimer(TMR_STEPMOT_CMD);
			OnSite_Controls_Enable(TRUE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�			
		}
	}
	else if (nIDEvent == TM_STATUS_CHECK) 
	{
		MotorStatusCheck();
	}
	else if (nIDEvent == TM_POSITION_CHECK) 
	{
		MotorPositionCheck();
	}


	CDialog::OnTimer(nIDEvent);
}

void CDialog_Manual_Module::Set_PickerUpDown(int OnOff, int PickerInfo[D_INFOSIZE][PICKER_NUM])
{
	int i;

	for (i = 0; i < PICKER_NUM; i++)
	{
		if(PickerInfo[D_EXIST][i] == YES)
		{
			FAS_IO.set_out_bit(st_io.o_ld_module_picker_updn[i], OnOff);
		}
		//else
		//{
		//	FAS_IO.set_out_bit(st_io.o_ld_module_picker_updn[i], !OnOff);
		//}
		b_PickerFlag[i] = FALSE;
		l_PickerWaitTime[i][0] = GetCurrentTime();
	}
}

int CDialog_Manual_Module::Get_PickerUpDown(int OnOff, int PickerInfo[D_INFOSIZE][PICKER_NUM])
{
	int i, FuncRet = RET_PROCEED;
	int RetVal[PICKER_NUM] = {0,};
	char jamcode[10] = {0,};
	CString str;
	
	if(st_basic.n_mode_device != CTL_YES)
	{
	}

	for(i = 0 ; i < PICKER_NUM ; i++)
	{
		RetVal[i] = NO;

		if(OnOff == IO_ON) //Picker ON (Down�̶��..)
		{
			if(PickerInfo[D_EXIST][i] == YES) //���� ��Ų ��Ŀ��!
			{
				if(b_PickerFlag[i] == FALSE && FAS_IO.get_in_bit(st_io.i_ld_module_picker_dn_chk[i], IO_ON) == IO_ON
					&& FAS_IO.get_in_bit(st_io.i_ld_module_picker_up_chk[i], IO_OFF) == IO_OFF)
				{
					b_PickerFlag[i] = TRUE;
					l_PickerWaitTime[i][0] = GetCurrentTime();   
				}
				else if(b_PickerFlag[i] == TRUE && FAS_IO.get_in_bit(st_io.i_ld_module_picker_dn_chk[i], IO_ON) == IO_ON
					&& FAS_IO.get_in_bit(st_io.i_ld_module_picker_up_chk[i], IO_OFF) == IO_OFF)
				{
					l_PickerWaitTime[i][1] = GetCurrentTime();  
					l_PickerWaitTime[i][2] = l_PickerWaitTime[i][1] - l_PickerWaitTime[i][0];
					
					if(l_PickerWaitTime[i][2] < 0)
					{
						l_PickerWaitTime[i][0] = GetCurrentTime();
					}
					if(l_PickerWaitTime[i][2] > st_wait.n_on_wait_time[38] + (i*2))
					{
						RetVal[i] = YES;
					}
				}
				else
				{
					l_PickerWaitTime[i][1] = GetCurrentTime();  
					l_PickerWaitTime[i][2] = l_PickerWaitTime[i][1] - l_PickerWaitTime[i][0];
					if(l_PickerWaitTime[i][2] < 0)
					{
						l_PickerWaitTime[i][0] = GetCurrentTime();
					}
					
					if(l_PickerWaitTime[i][2] > st_wait.n_limit_wait_time[38] + (i*2))
					{
						//400200 1 40 "Module Picker #1 Down Check Error."						
						sprintf(COMI.mc_alarmcode, "40020%d", i);
						sprintf(jamcode, "40020%d", i);						
						alarm.mstr_pcode = _T(jamcode); 
						alarm.mn_count_mode = 0;	
						alarm.mn_type_mode = eWARNING; 
						alarm.mn_alarm_assign_section = 186;

						FuncRet = RET_ERROR;
					}
				}
			}
			else RetVal[i] = YES;
		}
		else //Picker OFF (UP�̶��..)
		{
			if(PickerInfo[D_EXIST][i] == YES) //���� ��Ų ��Ŀ��!
			{
				if(b_PickerFlag[i] == FALSE && FAS_IO.get_in_bit(st_io.i_ld_module_picker_dn_chk[i], IO_OFF) == IO_OFF
					&& FAS_IO.Get_In_Bit(st_io.i_ld_module_picker_up_chk[i]) == IO_ON)
				{
					b_PickerFlag[i] = TRUE;
					l_PickerWaitTime[i][0] = GetCurrentTime();   
				}
				else if(b_PickerFlag[i] == TRUE && FAS_IO.get_in_bit(st_io.i_ld_module_picker_dn_chk[i], IO_OFF) == IO_OFF
					&& FAS_IO.Get_In_Bit(st_io.i_ld_module_picker_up_chk[i]) == IO_ON)
				{
					l_PickerWaitTime[i][1] = GetCurrentTime();  
					l_PickerWaitTime[i][2] = l_PickerWaitTime[i][1] - l_PickerWaitTime[i][0];
					
					if(l_PickerWaitTime[i][2] > st_wait.n_on_wait_time[38] + (i*2))
					{
						RetVal[i] = YES;
					}
				}
				else
				{
					l_PickerWaitTime[i][1] = GetCurrentTime();  
					l_PickerWaitTime[i][2] = l_PickerWaitTime[i][1] - l_PickerWaitTime[i][0];
					if(l_PickerWaitTime[i][2] < 0)
					{
						l_PickerWaitTime[i][0] = GetCurrentTime();
					}
					
					if(l_PickerWaitTime[i][2] > st_wait.n_limit_wait_time[38] + (i*2))
					{
						if(st_handler.cwnd_list != NULL)
						{
							str = _T("[UPICKER Error] Picker up sensor check error.");
							sprintf(st_msg.c_normal_msg,"%s", str);
							st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);
							Func.On_LogFile_Add(0, str);
							Func.On_LogFile_Add(99, str);
						}
						//400100 1 40 "Module Picker #1 Up Check Error."
						sprintf(COMI.mc_alarmcode, "40010%d", i);
						sprintf(jamcode,  "40010%d", i);					
						alarm.mstr_pcode = _T(jamcode); 
						alarm.mn_count_mode = 0;	
						alarm.mn_type_mode = eWARNING; 
						//st_handler.i_run_status = dWARNING;

						alarm.mn_alarm_assign_section = 187;

						FuncRet = RET_ERROR;
					}
				}
			}
			else RetVal[i] = YES;
		}
	}
	
	if(RetVal[0] == YES && RetVal[1] == YES) 
	{
		FuncRet = RET_GOOD;
	}

	return FuncRet;
}
void CDialog_Manual_Module::Set_FingerOnOff(int OnOff, int FingerInfo[D_INFOSIZE][PICKER_NUM])
{
	int i;

	for (i = 0; i < PICKER_NUM; i++)
	{
		if(FingerInfo[D_EXIST][i] == YES)
		{
			FAS_IO.set_out_bit(st_io.o_ld_module_glipper_onoff[i], OnOff);
		}
		//else
		//{
		//	FAS_IO.set_out_bit(st_io.o_ld_module_glipper_onoff[i], !OnOff);
		//}
		b_FingerFlag[i] = false;
		l_FingerWaitTime[i][0] = GetCurrentTime();
	}
}

int CDialog_Manual_Module::Get_FingerOnOff(int OnOff, int FingerInfo[D_INFOSIZE][PICKER_NUM])
{
	int i, FuncRet = RET_PROCEED;
	int RetVal[PICKER_NUM] = {0,};
	char jamcode[10] = {0,};
	 
	for(i = 0 ; i < PICKER_NUM ; i++)
	{
		RetVal[i] = NO;

		if(OnOff == IO_ON) //Finger ON (place���..)
		{
			if(FingerInfo[D_EXIST][i] == YES) //���� ��Ų �ΰŸ�!
			{
				//��¥�� ������ �����Ƿ� ���� �ð� �ڿ� ���� �Ϸ�� ����!!
				if(b_FingerFlag[i] == FALSE)
				{
					b_FingerFlag[i] = TRUE;
					l_FingerWaitTime[i][0] = GetCurrentTime();   
				}				
				else if(b_FingerFlag[i] == TRUE)
				{
					l_FingerWaitTime[i][1] = GetCurrentTime();  
					l_FingerWaitTime[i][2] = l_FingerWaitTime[i][1] - l_FingerWaitTime[i][0] ;
					
					if(l_FingerWaitTime[i][2] > st_wait.n_on_wait_time[39] + (i*2))
					{
						RetVal[i] = YES;
					}
				}
				else
				{
					l_FingerWaitTime[i][1] = GetCurrentTime();  
					l_FingerWaitTime[i][2] = l_FingerWaitTime[i][1] - l_FingerWaitTime[i][0];
					if(l_FingerWaitTime[i][2] < 0)
					{
						l_FingerWaitTime[i][0] = GetCurrentTime();
					}
					
					if(l_FingerWaitTime[i][2] > st_wait.n_limit_wait_time[39] + (i*2))
					{
						//400500 1 40 "Module Picker #1 Module On Check Error.[PS0400]."					
						sprintf(jamcode, "40050%d", i);
						alarm.mstr_pcode = _T(jamcode); 
						alarm.mn_count_mode = 0;	
						alarm.mn_type_mode = eWARNING; 
						alarm.mn_alarm_assign_section = 188;

						FuncRet = RET_ERROR;
					}
				}
			}
			else RetVal[i] = YES;
		}
		else //Finger OFF (Pick�̶��..)
		{
			if(FingerInfo[D_EXIST][i] == YES)
			{
				//��¥�� ������ �����Ƿ� ���� �ð� �ڿ� ���� �Ϸ�� ����!!
				if(b_FingerFlag[i] == FALSE)
				{
					b_FingerFlag[i] = TRUE;
					l_FingerWaitTime[i][0] = GetCurrentTime();   
				}				
				else if(b_FingerFlag[i] == TRUE)
				{
					l_FingerWaitTime[i][1] = GetCurrentTime();  
					l_FingerWaitTime[i][2] = l_FingerWaitTime[i][1] - l_FingerWaitTime[i][0];
					
					if(l_FingerWaitTime[i][2] > st_wait.n_on_wait_time[39] + (i*2))
					{
						RetVal[i] = YES;
					}
				}
				else
				{
					l_FingerWaitTime[i][1] = GetCurrentTime();  
					l_FingerWaitTime[i][2] = l_FingerWaitTime[i][1] - l_FingerWaitTime[i][0];
					if(l_FingerWaitTime[i][2] < 0)
					{
						l_FingerWaitTime[i][0] = GetCurrentTime();
					}
					
					if(l_FingerWaitTime[i][2] > st_wait.n_limit_wait_time[39] + (i*2))
					{
						//400600 1 40 "Module Picker #1 Module Off Check Error.[PS0400]."				
						sprintf(jamcode, "40060%d", i);
						alarm.mstr_pcode = _T(jamcode); 
						alarm.mn_count_mode = 0;	
						alarm.mn_type_mode = eWARNING; 
						alarm.mn_alarm_assign_section = 188;

						FuncRet = RET_ERROR;
					}
				}
			}
			else RetVal[i] = YES;
		}
	}
	
	if(RetVal[0] == YES && RetVal[1] == YES) 
	{
		FuncRet = RET_GOOD;
	}

	return FuncRet;
}
void CDialog_Manual_Module::Run_Init()
{
	int i,nRet_1 = RET_PROCEED, nRet_2 = RET_PROCEED;
	
	if(st_handler.mn_init_state[INIT_RBT_MODULE] != CTL_NO) return;

	switch(InitStep)
	{
	case 0:
		for (i = 0; i < PICKER_NUM; i++)
		{
			ActionPicker[D_EXIST][i] = YES;
		}
		Set_FingerOnOff(IO_OFF, ActionPicker);
		InitStep = 10;
		break;

	case 10:
		nRet_1 = Get_FingerOnOff(IO_OFF, ActionPicker);

		if(nRet_1 == RET_GOOD)
		{
			InitStep = 100;
		}
		else if(nRet_1 == RET_ERROR)
		{
			st_work.mn_run_status = CTL_dWARNING;
			InitStep = 10;
		}
		break;

	case 100:
		Set_PickerUpDown(IO_OFF, ActionPicker);
		InitStep = 200;
		break;

	case 200:
		// *************************************************************
		//  UP ��Ų �Ǹ����� CHECK�Ѵ�.                                 
		// *************************************************************
		nRet_1 = Get_PickerUpDown(IO_OFF, ActionPicker);

		if (nRet_1 == RET_GOOD)			// ���������� Up�� ���� ���.
		{
			InitStep = 1000;
		}
		else if (nRet_1 == RET_ERROR)
		{
			if(st_handler.cwnd_list != NULL)
			{
				sprintf(st_msg.c_abnormal_msg,"[Initialize Error] Do not Picker Up.");
				st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);
			}

		}
		break;

	case 1000:		//z axis���� homecheck ����!!
		// *************************************************************
		//  Ȩüũ�� �Ѵ�.                                              
		// *************************************************************
		nRet_1 = COMI.HomeCheck_Mot(M_M_RBT_Z, st_motor[M_M_RBT_Z].mn_homecheck_method, MOT_TIMEOUT);

		if(nRet_1 == CTLBD_RET_GOOD)			// ���������� Home Check�� ������ ���.
		{
			l_until_wait_time[0] = GetCurrentTime();
			InitStep = 1100;
		}
		else if (nRet_1 == CTLBD_RET_RETRY)
		{
			InitStep = 1000;
		}
		else if ((nRet_1 != CTLBD_RET_GOOD && nRet_1 != CTLBD_RET_PROCEED) )
		{
			st_work.mn_run_status = dWARNING;
			CTL_Lib.Alarm_Error_Occurrence(1101, st_work.mn_run_status, COMI.mc_alarmcode);
		}
		break;


	case 1100:
		l_until_wait_time[1] = GetCurrentTime();
		l_until_wait_time[2] = l_until_wait_time[1] - l_until_wait_time[0];
		if(l_until_wait_time[2] < 0)	l_until_wait_time[0] = GetCurrentTime(); //���� - ���̸� �ð� �ʱ�ȭ�Ͽ� �ٽ� üũ�Ѵ� 
		if(l_until_wait_time[2] < PICKERSTATUS_CHECK_TIME) 	break;

		nRet_1 = RET_GOOD;
		for (i = 0; i < PICKER_NUM; i++)
		{
			if(ActionPicker[D_EXIST][i] == DVC_YES && st_picker.n_module_ldrbt_enable[i] == YES)
			{
				if(FAS_IO.get_in_bit(st_io.i_ld_module_dvc_chk[i], IO_ON) == IO_OFF)
				{
					if(st_handler.cwnd_list != NULL)
					{
						sprintf(st_msg.c_abnormal_msg,"[Initialize Error] Module Picker #1 Module On Check Error.");
						st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);
					}
					nRet_1 = RET_ERROR;
					break;
				}
			}
		}

		if(nRet_1 == RET_GOOD)
		{
			InitStep = 2000;	
		}
		break;
		
	case 2000:
		nRet_1 = COMI.HomeCheck_Mot(M_M_RBT_Y, st_motor[M_M_RBT_Y].mn_homecheck_method, MOT_TIMEOUT);

		if(nRet_1 == CTLBD_RET_GOOD)			// ���������� Home Check�� ������ ���.
		{
			InitStep = 3000;
		}
		else if (nRet_1 == CTLBD_RET_RETRY)
		{
			InitStep = 2000;
		}
		else if ((nRet_1 != CTLBD_RET_GOOD && nRet_1 != CTLBD_RET_PROCEED) )
		{
			if(st_handler.cwnd_list != NULL)
			{
				sprintf(COMI.mc_alarmcode,"%s", alarm.mstr_code);
				st_work.mn_run_status = dWARNING;
				CTL_Lib.Alarm_Error_Occurrence(1102, st_work.mn_run_status, COMI.mc_alarmcode);
			}

		}
		break;


	case 3000:
		st_handler.mn_init_state[INIT_RBT_MODULE] = CTL_YES;
		InitStep = 0;
		break;		
	}
}

BOOL CDialog_Manual_Module::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_KEYDOWN)
	{
		if (pMsg->wParam == VK_RETURN)
		{
			return TRUE;
		}

		if (pMsg->wParam == VK_ESCAPE)
		{
			return TRUE;
		}
	}		
	return CDialog::PreTranslateMessage(pMsg);
}

void CDialog_Manual_Module::OnBtnStop() 
{
	mn_stop_req = TRUE;	
}


int CDialog_Manual_Module::OnSite_Move_Excution()
{
	int nFuncRet = CTLBD_RET_PROCEED;
	int nRet_1 = CTLBD_RET_PROCEED, n_chk;	
	
	// **************************************************************************
	// ���� ���� �� ESTOP ��û �߻��ߴ��� �˻��Ѵ�                               
	// -> ESTOP ��û �߻��� ��� ��� ������ ���� �����                         
	// **************************************************************************
	if (mn_stop_req == TRUE)
	{
		if (mn_move_step < 100)
			mn_move_step = 100;
	}
	// **************************************************************************
	
	switch(mn_move_step)
	{
	case 0 :
		// **********************************************************************
		// ���� Ư�� ��ġ�� �̵���Ų��. (�̵���ġ ����~)                         
		// **********************************************************************
		n_chk = COMI.Start_SingleMove(mn_motor_no, md_mot_start_pos, st_basic.nManualSpeed);
		if (n_chk == CTLBD_RET_GOOD)
		{
			mn_move_step = 10;
		}
		else if (nRet_1 == CTLBD_RET_RETRY)
		{
			mn_move_step = 0; 
		}
		else if ((nRet_1 != CTLBD_RET_GOOD && nRet_1 != CTLBD_RET_PROCEED) )
		{
			mn_move_step = 130;
		}
		// **********************************************************************
		break;

	case 10 :
		n_chk = COMI.Check_SingleMove(mn_motor_no, md_mot_start_pos);

		if (n_chk == CTLBD_RET_GOOD)
		{
			if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
			{
				sprintf(st_msg.c_normal_msg, "[MODULE SITE] Motor completed transfer.");
				st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, NORMAL_MSG);  // ���� �Ϸ� ��� ��û
			}

			if (mn_stop_req != FALSE)	mn_stop_req = FALSE;
			mn_move_step = 0;
			nFuncRet = CTLBD_RET_GOOD;
		}
		else if (n_chk == CTLBD_RET_ERROR)
		{
			if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
			{
				//st_msg.mstr_abnormal_msg = _T("[" + m_str_cmd_motor + "] Motor failed to move.");
				sprintf(st_msg.c_abnormal_msg, "[" + m_str_cmd_motor + "] Motor failed to move.");
				st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� ���� ��� ��û
			}
			nFuncRet = CTLBD_RET_ERROR;
		}
		else if (n_chk == CTLBD_RET_SAFETY)
		{
			if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
			{
				//st_msg.mstr_abnormal_msg = _T("[SAFETY] Do not move being thought that is not safe at relevant motor difference.");
				sprintf(st_msg.c_abnormal_msg, "[SAFETY] Do not move being thought that is not safe at relevant motor difference.");
				st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� ���� ��� ��û
			}
			nFuncRet = CTLBD_RET_ERROR;
		}
		break;

	case 100 :
		// **********************************************************************
		// Ư�� �� ��� ���� �̺�Ʈ�� ���� �����Ѵ�                              
		// **********************************************************************
		n_chk = COMI.Set_MotStop(0, mn_motor_no);
		
		if (n_chk == TRUE)
			mn_move_step = 110;
		else 
		{
			if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
			{
				st_other.str_abnormal_msg = _T("[MODULE SITE] Though canceled transfer of motor, error happened.");
				st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� ���� ��� ��û
			}
			mn_move_step = 120;
		}
		// **********************************************************************
		
		break;
	case 110 :
		if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
		{
			st_other.str_op_msg = _T("[LOADER SITE] Motor shut down during transfer.");
			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, NORMAL_MSG);  // ���� �Ϸ� ��� ��û
		}

		if (mn_stop_req != FALSE)
			mn_stop_req = FALSE;  // ESTOP ��û �÷��� �ʱ�ȭ

		mn_move_step = 0;
		nFuncRet = CTLBD_RET_GOOD;
		break;

	case 120 :
		if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
		{
			st_other.str_abnormal_msg = _T("[LOADER SITE] Transfer command of motor failed.");
			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� ���� ��� ��û
		}

		if (mn_stop_req != FALSE)
			mn_stop_req = FALSE;  // ESTOP ��û �÷��� �ʱ�ȭ

		mn_move_step = 0; 
		nFuncRet = CTLBD_RET_ERROR;
		break;

	case 130 :
		if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
		{
			st_other.str_abnormal_msg = _T("[MODULE SITE] Transfer command of motor failed.");
			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� ���� ��� ��û
		}

		if (mn_stop_req != FALSE)
			mn_stop_req = FALSE;  // ESTOP ��û �÷��� �ʱ�ȭ

		mn_move_step = 0; 
		nFuncRet = CTLBD_RET_ERROR;
		break;
	}

	return nFuncRet;
}

void CDialog_Manual_Module::OnBtnHome() 
{
	CString strTmp;
	int nMotorPos = 0;

	OnSite_Controls_Enable(FALSE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�

	if (st_handler.mn_menu_lock != TRUE)
	{
		st_handler.mn_menu_lock = TRUE;
	}
	// ==============================================================================
	
	
	OnSite_Step_Clear();
	
	mn_cmd_no = HOMING;

	nMotorPos = m_cmb_motor_pos.GetCurSel();

	if(nMotorPos == 0)
	{
		mn_motor_no = M_M_RBT_Y;
	}
	else if(nMotorPos == 1)
	{
		mn_motor_no = M_M_RBT_Z;
	}
	else if(nMotorPos == 2)
	{
		mn_motor_no = M_LDM_STACKER_1;
	}
	else if(nMotorPos == 3)
	{
		mn_motor_no = M_LDM_STACKER_2;
	}
	else if(nMotorPos == 4)
	{
		mn_motor_no = M_LDM_STACKER_MOVE;
	}
	else
	{
		mn_motor_no = M_WORK_BUFFER_1 + nMotorPos - 5;
	}

	// ==============================================================================
	// -> HOMING �۾� ó�� �Լ��� CPublic_Function Ŭ������ ����                 
	// ==============================================================================
	st_handler.mn_home_state[mn_motor_no] = CTL_READY;	// ���� HOMING �Ϸ� �÷���
	// ==============================================================================
	
	st_motor[mn_motor_no].mn_home_step	= 0;
	COMI.mn_home_step[mn_motor_no] = 0;

	strTmp.Format("[Motor] (%d)_Axis Home Move", mn_motor_no);
	Func.On_LogFile_Add(99, strTmp);
	
	SetTimer(TMR_MODULEMOT_CMD, 100, NULL);			// ���� ���� ���� Ÿ�̸�	
}


int CDialog_Manual_Module::OnSite_Homing_Excution()
{
	int n_home_flag = CTLBD_RET_PROCEED;
	int nRet;

	// =============================================================================
	// ���� ���� �� ESTOP ��û �߻��ߴ��� �˻��Ѵ�
	// -> ESTOP ��û �߻��� ��� ��� ������ ���� �����
	// =============================================================================
	if (mn_stop_req){
		if (mn_home_step < 100){
			mn_home_step = 100;
		}
	}
	// =============================================================================
	if(FAS_IO.get_in_bit(st_io.i_stacker_light_curtain_chk, IO_ON) == IO_ON ||
		FAS_IO.get_in_bit(st_io.i_vision_light_curtain_chk, IO_ON) == IO_ON)
	{
		COMI.Set_MotStop(0, mn_motor_no);
		if(st_handler.cwnd_list != NULL)
		{
			sprintf(st_msg.c_abnormal_msg,"[Manual Error] Area sensor is detected. Motor stop. ReWork Please");
			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);
		}
		COMI.mn_home_step[mn_motor_no] = 0;
		mn_home_step = 100;
		return n_home_flag;
	}

	switch(mn_home_step)
	{
		case 0 :
			nRet = COMI.HomeCheck_Mot(mn_motor_no, st_motor[mn_motor_no].mn_homecheck_method, MOT_TIMEOUT);

			if (nRet == CTLBD_RET_GOOD)				// ���������� Home Check�� ������ ���.
			{
				if (mn_stop_req != FALSE)
					mn_stop_req = FALSE;		// ESTOP ��û �÷��� �ʱ�ȭ
				
				mn_home_step = 0; 
				n_home_flag = CTLBD_RET_GOOD;
			}
			else if (nRet == CTLBD_RET_ERROR)		// Home Check�� ���� ���� ���.
			{
				if (mn_stop_req != FALSE)
					mn_stop_req = FALSE;		// ESTOP ��û �÷��� �ʱ�ȭ
				
				mn_home_step = 0; 
				n_home_flag = CTLBD_RET_ERROR;
			}
			else if (nRet == CTLBD_RET_SAFETY)
			{
				if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
				{
					//st_msg.mstr_abnormal_msg = _T("[SAFETY] Do not move being thought that is not safe at relevant motor difference.");
					sprintf(st_msg.c_abnormal_msg, "[SAFETY] Do not move being thought that is not safe at relevant motor difference.");
					st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� ���� ��� ��û
				}
				mn_home_step = 0; 
				n_home_flag = CTLBD_RET_ERROR;
			}
			break;

		case 100 :
			// =============================================================================
			// Ư�� �� ��� ���� �̺�Ʈ�� ���� �����Ѵ�
			// =============================================================================
			nRet = COMI.Set_MotStop(0, mn_motor_no);

			if (nRet == CTLBD_RET_GOOD)
			{
				mn_home_step = 110;
			}
			else 
			{
				if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
				{
					//st_msg.mstr_abnormal_msg = _T("[" + m_str_cmd_motor + "] Though canceled transfer of motor, error happened.");
					sprintf(st_msg.c_abnormal_msg, "[ + mn_motor_no + ] Though canceled transfer of motor, error happened.");
					st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� ���� ��� ��û
				}
				
				mn_home_step = 120;
			}
			break;

		case 110 :
			if (st_handler.cwnd_list != NULL)
			{  // ����Ʈ �� ȭ�� ���� //
			//	st_msg.mstr_normal_msg = _T("[" + m_str_cmd_motor + "] Motor shut down during transfer.");
				sprintf(st_msg.c_normal_msg, "[ + mn_motor_no + ] Motor shut down during transfer.");
				st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, NORMAL_MSG);  // ���� �Ϸ� ��� ��û //
			}

			//if (m_nstop_req != FALSE){
			if (mn_stop_req){
				mn_stop_req = FALSE;		// ESTOP ��û �÷��� �ʱ�ȭ
			}

			mn_home_step = 0;
			n_home_flag = CTLBD_RET_GOOD;
			break;

		case 120 :
			if (st_handler.cwnd_list != NULL)
			{  // ����Ʈ �� ȭ�� ���� //

				//st_msg.mstr_abnormal_msg = _T("[" + m_str_cmd_motor + "] Transfer command of motor failed.");
				sprintf(st_msg.c_abnormal_msg, "[ + mn_motor_no + ] Transfer command of motor failed.");
				st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� ���� ��� ��û //
			}

			//if (m_nstop_req != FALSE){
			if (mn_stop_req)
			{
				mn_stop_req = FALSE;	// ESTOP ��û �÷��� �ʱ�ȭ //
			}

			st_motor[mn_motor_no].mn_home_step = 0;
			mn_home_step = 0; 
			n_home_flag = CTLBD_RET_ERROR;
			break;

		case 130 :
			if (st_handler.cwnd_list != NULL)
			{  // ����Ʈ �� ȭ�� ���� //
				//st_msg.mstr_abnormal_msg = _T("[" + m_str_cmd_motor + "] Transfer command of motor failed.");
				sprintf(st_msg.c_abnormal_msg, "[" + m_str_cmd_motor + "] Transfer command of motor failed.");
				st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� ���� ��� ��û //
			}

			//if (m_nstop_req != FALSE){
			if (mn_stop_req)
			{
				mn_stop_req = FALSE;	// ESTOP ��û �÷��� �ʱ�ȭ //
			}

			st_motor[mn_motor_no].mn_home_step = 0;
			mn_home_step = 0; 
			n_home_flag = CTLBD_RET_ERROR;
			break;
	}

	return  n_home_flag;
}

void CDialog_Manual_Module::OnBtnGoStepRbtMove() 
{
	// TODO: Add your control notification handler code here
	CDialog_Message msg_dlg;
	int mn_response;

	st_msg.str_fallacy_msg = _T("Step Robot Move �׽�Ʈ�� �Ͻðڽ��ϱ�?");
	if(st_handler.mn_language == LANGUAGE_ENGLISH)
	{
		st_msg.str_fallacy_msg = _T("Would you like to test Step Robot Move");
	}

	mn_response = msg_dlg.DoModal();
	if (mn_response != IDOK) return;

	if (st_handler.mn_menu_lock != TRUE)
		st_handler.mn_menu_lock = TRUE;

	OnSite_Controls_Enable(FALSE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
	OnSite_Step_Clear();
	
	st_handler.mn_init_state[INIT_RBT_MODULE] = CTL_READY;
	InitStep = 0;

	SetTimer(TMR_STEPMOT_CMD, 100, NULL);			// ���� ���� ���� Ÿ�̸�	
	
	
}

/////////////////////////////////////////// 20121006
void CDialog_Manual_Module::OnCellClick(WPARAM wParam, LPARAM lParam)
{
	LPSS_CELLCOORD lpcc = (LPSS_CELLCOORD)lParam;
	CDialog_Message msg_dlg;

	CString strTmp, strChange, str_file;
	CString str_tmp, str_data;
	int nResponse;

	CString strText;
	
	CDialog_KeyPad	pad_dlg;
	
	int n_response;
	int nMotorPos = 0;

	if (st_handler.mn_menu_lock) return;

	nMotorPos = m_cmb_motor_pos.GetCurSel();

	if(nMotorPos == 0)
	{
		m_n_axis = M_M_RBT_Y;
	}
	else if(nMotorPos == 1)
	{
		m_n_axis = M_M_RBT_Z;
	}
	else if(nMotorPos == 2)
	{
		m_n_axis = M_LDM_STACKER_1;
	}
	else if(nMotorPos == 3)
	{
		m_n_axis = M_LDM_STACKER_2;
	}
	else if(nMotorPos == 4)
	{
		m_n_axis = M_LDM_STACKER_MOVE;
	}
	else
	{
		m_n_axis = M_WORK_BUFFER_1 + nMotorPos - 5;
	}
	
	if (nMotorPos < 0)	
	{
		if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
		{
			sprintf(st_msg.c_abnormal_msg,"[Manual Module] �̵� ���� ���õ��� �ʾҽ��ϴ�.");
			if(st_handler.mn_language == LANGUAGE_ENGLISH) 
			{
				sprintf(st_msg.c_abnormal_msg, "[Manual Module] was not selected Axis");
			}

			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� �Ϸ� ��� ��û
		}
		return;
	}

		m_grid_motor_info = (TSpread*)GetDlgItem(IDC_CUSTOM_MOTOR_INFO);

		switch(lpcc->Row)
		{
		case 3:
		case 4:
			switch(lpcc->Col)
			{
			case 3:
			case 4:
				if (COMI.mn_motorbd_init_end != TRUE)  
				{
					st_msg.str_fallacy_msg = _T("First, you may initialize motion board.");
					
					nResponse = msg_dlg.DoModal();
					if (nResponse == IDOK) return ;
				}
				strTmp.Format("[Motor] (%s)_Axis Power Off", m_str_axis_name);
				Func.On_LogFile_Add(99, strTmp);
				
				COMI.Set_MotPower(m_n_axis, FALSE);
				break;
				
			case 5:
			case 6:
				if (COMI.mn_motorbd_init_end != TRUE)  
				{
					st_msg.str_fallacy_msg = _T("First, you may initialize motion board.");
					
					nResponse = msg_dlg.DoModal();
					if (nResponse == IDOK) return ;
				}
				strTmp.Format("[Motor] (%s)_Axis Power On", m_str_axis_name);
				Func.On_LogFile_Add(99, strTmp);
				
				COMI.Set_MotPower(m_n_axis, TRUE);
				break;
			}
			break;
			
			case 5:
			case 6:
				if (lpcc->Col == 3 || lpcc->Col == 4 || lpcc->Col == 5 || lpcc->Col == 6)
				{
					if (COMI.mn_motorbd_init_end != TRUE)  
					{
						st_msg.str_fallacy_msg = _T("First, you may initialize motion board.");
						
						nResponse = msg_dlg.DoModal();
						if (nResponse == IDOK) return ;
					}
					
					strTmp.Format("[Motor] (%s)_Axis Alarm Clear", m_str_axis_name);
					Func.On_LogFile_Add(99, strTmp);
					
					COMI.Set_MotAlarmClear(m_n_axis);
				}
				break;
				
			case 8:
				switch(lpcc->Col)
				{
				case 1:
					if (m_n_move_mode != 0)
					{
						m_n_move_mode = 0;
						
						m_p_grid.GridCellColor(m_grid_motor_info, 8, 1, RED_C, BLACK_C);
						m_p_grid.GridCellColor(m_grid_motor_info, 8, 2, BLACK_L, YELLOW_C);
					}
					break;
					
				case 2:
					if (m_n_move_mode != 1)
					{
						m_n_move_mode = 1;
						
						m_p_grid.GridCellColor(m_grid_motor_info, 8, 1, BLACK_L, YELLOW_C);
						m_p_grid.GridCellColor(m_grid_motor_info, 8, 2, RED_C, BLACK_C);
					}
					break;
					
				case 5:
				case 6:
					strTmp.Format("%.3f", m_d_data);
					st_msg.mstr_keypad_msg.Format("[Jog Data]  set");
					st_msg.mstr_keypad_val = strTmp;
					
					st_msg.mstr_pad_high_limit.Format("10000.0");
					st_msg.mstr_pad_low_limit.Format("0.001");
					
					st_msg.mn_dot_use = CTL_YES;
					st_msg.mn_pad_dialog = CTL_YES;
					
					n_response = pad_dlg.DoModal();
					
					if (n_response == IDOK)
					{
						strTmp = st_msg.mstr_keypad_val;
						m_d_data = atof(strTmp);
						m_p_grid.GridCellText(m_grid_motor_info, 8, 5, strTmp);
					}
					else if (n_response == IDCANCEL)
					{
						
					}
					break;
					
				}
				break;
		}
}

LONG CDialog_Manual_Module::OnUserLButtonDown(WPARAM wParam, LPARAM lParam)
{
	CDialog_Message msg_dlg;
	CString strTmp;
	int		nRet;
	double  dmot_curr_pos;
	
	nRet = Func.DoorOpenCheckSpot();
	
	if (nRet == CTLBD_RET_ERROR)
	{
		return 0;
	}

	// Velocity-Move(Jog) ����϶��� WM_LBUTTONDOWN �̺�Ʈ�� ó���Ѵ�. //
	// Rel/Abs Position Mode������ WM_LBUTTONUP �̺�Ʈ���� �̼� ������ //
	// ó���Ѵ�.                                                       //
	CButtonST *pButton = (CButtonST *)lParam;

	nRet = pButton->GetTag();

	if (pButton->GetTag() == IDC_BTN_LEFT)
	{ // "Jog (-)" ��ư�� ���� ���...
		if (m_n_move_mode == 0)//20120716 0->1
		{
			nRet = CTL_Lib.Motor_SafetyCheck(0, m_n_axis, 0);
			
			if (nRet == CTLBD_RET_ERROR)
			{
				return 0;
			}
			
			OnButtonControl(FALSE);	
			
			strTmp.Format("[Motor] (%s)_Axis - Jog Move", m_str_axis_name);
			Func.On_LogFile_Add(99, strTmp);
			
			COMI.Set_MotSpeed(MOT_SPD_JOG, m_n_axis, cmSMODE_KEEP, st_motor[m_n_axis].md_spd_jog, st_motor[m_n_axis].md_spd_acc, st_motor[m_n_axis].md_spd_dec);		// ���� �ӵ��� �����Ѵ�.
			
			if (cmmSxVMoveStart(m_n_axis, MINUS) != cmERR_NONE)
			{ 
				cmmErrShowLast(GetSafeHwnd());
			}
			else
			{
				st_handler.mn_menu_lock = FALSE;
			}
		}
		else
		{
			// ���� �̵����� ���� üũ �߰� �ؾߵ�......
			OnButtonControl(FALSE);							// ��ư ��Ȱ��ȭ
			MotorMoveStepClear();							// �������� �Լ� ���� �ʱ�ȭ
			
			mn_motor_no = m_n_cmd_motor_no	= m_n_axis;					// ���� ��ȣ ����
			mn_cmd_no = MOT_MOVE;					// ���� ���� ��ȣ ���� [���� �̵� ����]
//			m_n_cmd_no			= MOVING;							// ���� ���� ��ȣ ���� [���� �̵� ����]
			m_d_mot_goto_spd	= (st_motor[m_n_cmd_motor_no].md_spd_jog / COMI.md_spd_vel[m_n_cmd_motor_no][0]) * 100;
			m_str_cmd_motor		= m_str_axis_name;
			
			dmot_curr_pos		= COMI.Get_MotCurrentPos(m_n_axis);
			
//			m_d_mot_goto_pos	= dmot_curr_pos - m_d_data;
			md_mot_start_pos	= dmot_curr_pos - m_d_data;
			strTmp.Format("[Motor] (%s)_Axis (%.3f) - Data Move", m_str_axis_name, md_mot_start_pos);
			Func.On_LogFile_Add(99, strTmp);
			
			SetTimer(TMR_MODULEMOT_CMD, 10, NULL);
		}
	}
	else if (pButton->GetTag() == IDC_BTN_RIGHT)
	{ 
		if (m_n_move_mode == 0)//20120716 0->1
		{
			nRet = CTL_Lib.Motor_SafetyCheck(0, m_n_axis, 0);
			
			if (nRet == CTLBD_RET_ERROR)
			{
				return 0;
			}
			
			OnButtonControl(FALSE);						// ��ư ��Ȱ��ȭ
			
			strTmp.Format("[Motor] (%s)_Axis + Jog Move", m_str_axis_name);
			Func.On_LogFile_Add(99, strTmp);
			
			COMI.Set_MotSpeed(MOT_SPD_JOG, m_n_axis, cmSMODE_KEEP, st_motor[m_n_axis].md_spd_jog, st_motor[m_n_axis].md_spd_acc, st_motor[m_n_axis].md_spd_dec);		// ���� �ӵ��� �����Ѵ�.
			
			if (cmmSxVMoveStart(m_n_axis, PLUS) != cmERR_NONE)
			{ 
				cmmErrShowLast(GetSafeHwnd());
			}
			else
			{
				st_handler.mn_menu_lock = FALSE;
			}
		}
		else
		{
			// ���� �̵����� ���� üũ �߰� �ؾߵ�......				
			OnButtonControl(FALSE);						// ��ư ��Ȱ��ȭ
			MotorMoveStepClear();							// �������� �Լ� ���� �ʱ�ȭ

			mn_motor_no = m_n_cmd_motor_no	= m_n_axis;					// ���� ��ȣ ����
			mn_cmd_no = MOT_MOVE;					// ���� ���� ��ȣ ���� [���� �̵� ����]
//			m_n_cmd_no			= MOVING;							// ���� ���� ��ȣ ���� [���� �̵� ����]
			m_d_mot_goto_spd	= (st_motor[m_n_cmd_motor_no].md_spd_jog / COMI.md_spd_vel[m_n_cmd_motor_no][0]) * 100;
			m_str_cmd_motor		= m_str_axis_name;
			
			dmot_curr_pos		= COMI.Get_MotCurrentPos(m_n_axis);
			
//			m_d_mot_goto_pos	= dmot_curr_pos + m_d_data;
			md_mot_start_pos	= dmot_curr_pos + m_d_data;			
			strTmp.Format("[Motor] (%s)_Axis (%.3f) + Data Move", m_str_axis_name, md_mot_start_pos);
			Func.On_LogFile_Add(99, strTmp);
			
			SetTimer(TMR_MODULEMOT_CMD, 10, NULL);
		}
	}

	return 0;
}

LONG CDialog_Manual_Module::OnUserLButtonUp(WPARAM wParam, LPARAM lParam)
{	
	CDialog_Message msg_dlg;
	CString strTmp;
	int		nRet;

	nRet = Func.DoorOpenCheckSpot();
	
	if (nRet == CTLBD_RET_ERROR)
	{
 		st_msg.str_fallacy_msg = _T("If the Open Door, does not work.");
 		::PostMessage(st_handler.hWnd, WM_MAINFRAME_WORK, 1000, 0);
		return 0;
	}

	// Velocity-Move(Jog) ����϶��� WM_LBUTTONDOWN �̺�Ʈ�� ó���Ѵ�. //
	// Rel/Abs Position Mode������ WM_LBUTTONUP �̺�Ʈ���� �̼� ������ //
	// ó���Ѵ�.                                                       //
	CButtonST *pButton = (CButtonST *)lParam;

	nRet = pButton->GetTag();

	if (pButton->GetTag() == IDC_BTN_LEFT)
	{ // "Jog (-)" ��ư�� ���� ���...
		if (m_n_move_mode == 0)//20120716 0->1
		{
			strTmp.Format("[Motor] (%s)_Axis - Jog Stop", m_str_axis_name);
			Func.On_LogFile_Add(99, strTmp);
			
			cmmSxStop(m_n_axis, FALSE, TRUE);  // ���� �̵� ���� �Լ� 
			
			OnButtonControl(TRUE);	
		}
	}
	else if (pButton->GetTag() == IDC_BTN_RIGHT)
	{ 
		if (m_n_move_mode == 0)//20120716 0->1
		{
			strTmp.Format("[Motor] (%s)_Axis + Jog Stop", m_str_axis_name);
			Func.On_LogFile_Add(99, strTmp);
			
			cmmSxStop(m_n_axis, FALSE, TRUE);  // ���� �̵� ���� �Լ� 
			
			OnButtonControl(TRUE);	
		}
	}
	return 0;
}

// void CDialog_Manual_Module::OnBtnHome() 
// {
// 	CString strTmp;
// 
// 	OnButtonControl(FALSE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
// 	
// 	// ==============================================================================
// 	// �޴� ��� �Ұ����ϵ��� �÷��� �����Ѵ�                                    
// 	// -> ���� ���� ���� �߿� �ٸ� �޴� ���� ���۽�Ű�� �������� �� �ֱ� �����̴�
// 	// -> st_handler.i_menu_lock   : �޴� ��� ���� ���� �÷���                  
// 	//  : ���� �������� �޴� ��ȯ �κп��� �� �÷��� �˻��ϰ� �ȴ�               
// 	// ==============================================================================
// 	if (st_handler.mn_menu_lock != TRUE)
// 	{
// 		st_handler.mn_menu_lock = TRUE;
// 	}
// 	// ==============================================================================
// 	
// 	// ==============================================================================
// 	// -> HOMING �۾� ó�� �Լ��� CPublic_Function Ŭ������ ����                 
// 	// ==============================================================================
// 	st_handler.mn_home_state[m_n_axis] = CTL_READY;	// ���� HOMING �Ϸ� �÷���
// 	// ==============================================================================
// 	
// 	MotorMoveStepClear();							// �������� �Լ� ���� �ʱ�ȭ
// 	
// 	m_n_cmd_motor_no						= m_n_axis;					// ���� ��ȣ ����
// 	m_n_cmd_no								= HOMING;							// ���� ���� ��ȣ ���� [���� �̵� ����]
// 	m_str_cmd_motor							= m_str_axis_name;
// 	
// 	strTmp.Format("[Motor] (%s)_Axis Home Move", m_str_axis_name);
// 	Func.On_LogFile_Add(99, strTmp);
// 
// 	st_motor[m_n_cmd_motor_no].mn_home_step	= 0;
// 	COMI.mn_home_step[m_n_cmd_motor_no] = 0;
// 	
// 	SetTimer(TM_HOME_CHECK, 100, NULL);			// ���� ���� ���� Ÿ�̸�
//}

void CDialog_Manual_Module::OnButtonControl(BOOL b_flag)
{
	
}

void CDialog_Manual_Module::MotorMoveStepClear()
{
 	mn_stop_req = FALSE;	// ESTOP ��û �÷��� �ʱ�ȭ
	
	m_n_cmd_no = 0;			// ���� ���� ��ȣ ���� ���� �ʱ�ȭ
	m_n_cmd_motor_no = -1;	// ���� ��ȣ ���� ���� �ʱ�ȭ
	m_str_cmd_motor = _T("Motor NULL");
	
 	mn_home_step = 0;		// ���� HOMING ó�� ���� ���� ���� �ʱ�ȭ
 	mn_move_step = 0;		// ���� �̵� ó�� ���� ���� ���� �ʱ�ȭ
}

///////////////////////////////////////////

void CDialog_Manual_Module::MotorStatusCheck()
{
	m_grid_motor_info = (TSpread*)GetDlgItem(IDC_CUSTOM_MOTOR_INFO);

	if (m_n_home == 0)
	{
		if (m_n_sd == 1)
		{
			if (m_n_minus_el == 1)
			{
				if (COMI.Get_MotIOSensor(m_n_axis, MOT_SENS_ELM) == CTLBD_RET_GOOD)
				{
					m_p_grid.GridCellColor(m_grid_motor_info, 2, 1, RED_C, WHITE_C);
				}
				else
				{
					m_p_grid.GridCellColor(m_grid_motor_info, 2, 1, BLACK_L, WHITE_C);
				}
			}
			
			if (COMI.Get_MotIOSensor(m_n_axis, MOT_SENS_SD) == CTLBD_RET_GOOD)
			{
				m_p_grid.GridCellColor(m_grid_motor_info, 2, 3, RED_C, WHITE_C);
			}
			else
			{
				m_p_grid.GridCellColor(m_grid_motor_info, 2, 3, BLACK_L, WHITE_C);
			}
			
			if (m_n_plus_el == 1)
			{
				if (COMI.Get_MotIOSensor(m_n_axis, MOT_SENS_ELP) == CTLBD_RET_GOOD)
				{
					m_p_grid.GridCellColor(m_grid_motor_info, 2, 5, RED_C, WHITE_C);
				}
				else
				{
					m_p_grid.GridCellColor(m_grid_motor_info, 2, 5, BLACK_L, WHITE_C);
				}
			}
		}
		else
		{
			if (m_n_minus_el == 1)
			{
				if (COMI.Get_MotIOSensor(m_n_axis, MOT_SENS_ELM) == CTLBD_RET_GOOD)
				{
					m_p_grid.GridCellColor(m_grid_motor_info, 2, 1, RED_C, WHITE_C);
				}
				else
				{
					m_p_grid.GridCellColor(m_grid_motor_info, 2, 1, BLACK_L, WHITE_C);
				}
			}
			
			if (m_n_plus_el == 1)
			{
				if (COMI.Get_MotIOSensor(m_n_axis, MOT_SENS_ELP) == CTLBD_RET_GOOD)
				{
					m_p_grid.GridCellColor(m_grid_motor_info, 2, 4, RED_C, WHITE_C);
				}
				else
				{
					m_p_grid.GridCellColor(m_grid_motor_info, 2, 4, BLACK_L, WHITE_C);
				}
			}
		}
	}
	else
	{
		if (m_n_minus_el == 1)
		{
			if (COMI.Get_MotIOSensor(m_n_axis, MOT_SENS_ELM) == CTLBD_RET_GOOD)
			{
				m_p_grid.GridCellColor(m_grid_motor_info, 2, 1, RED_C, WHITE_C);
			}
			else
			{
				m_p_grid.GridCellColor(m_grid_motor_info, 2, 1, BLACK_L, WHITE_C);
			}
		}
		
		if (COMI.Get_MotIOSensor(m_n_axis, MOT_SENS_HOME) == CTLBD_RET_GOOD)
		{
			m_p_grid.GridCellColor(m_grid_motor_info, 2, 3, RED_C, WHITE_C);
		}
		else
		{
			m_p_grid.GridCellColor(m_grid_motor_info, 2, 3, BLACK_L, WHITE_C);
		}
		
		if (m_n_plus_el == 1)
		{
			if (COMI.Get_MotIOSensor(m_n_axis, MOT_SENS_ELP) == CTLBD_RET_GOOD)
			{
				m_p_grid.GridCellColor(m_grid_motor_info, 2, 5, RED_C, WHITE_C);
			}
			else
			{
				m_p_grid.GridCellColor(m_grid_motor_info, 2, 5, BLACK_L, WHITE_C);
			}
		}
	}

	if (COMI.Get_MotPower(m_n_axis) == CTLBD_RET_GOOD)
	{
		m_p_grid.GridCellColor(m_grid_motor_info, 4, 1, RED_C, WHITE_C);
	}
	else
	{
		m_p_grid.GridCellColor(m_grid_motor_info, 4, 1, BLACK_L, WHITE_C);
	}

	if (COMI.Get_MotAlarmStatus(m_n_axis) == CTLBD_RET_GOOD)
	{
		m_p_grid.GridCellColor(m_grid_motor_info, 6, 1, BLACK_L, WHITE_C);
	}
	else
	{
		m_p_grid.GridCellColor(m_grid_motor_info, 6, 1, RED_C, WHITE_C);
	}
}

void CDialog_Manual_Module::MotorPositionCheck()
{
//	m_dgt_current_pos.SetVal(COMI.Get_MotCurrentPos(st_part.n_motor_axis[MOTOR_PART]));
	CString str_tmp;

	m_grid_motor_info = (TSpread*)GetDlgItem(IDC_CUSTOM_MOTOR_INFO);

	str_tmp.Format("%.3f", COMI.Get_MotCurrentPos(m_n_axis));
	m_p_grid.GridCellText(m_grid_motor_info, 8, 3, str_tmp);
}


void CDialog_Manual_Module::OnSelchangeCmbMotorPos() 
{
	// TODO: Add your control notification handler code here
	int nMotorPos = m_cmb_motor_pos.GetCurSel();
	
	if(nMotorPos == 0)
	{
		m_n_axis = M_M_RBT_Y;
	}
	else if(nMotorPos == 1)
	{
		m_n_axis = M_M_RBT_Z;
	}
	else if(nMotorPos == 2)
	{
		m_n_axis = M_LDM_STACKER_1;
	}
	else if(nMotorPos == 3)
	{
		m_n_axis = M_LDM_STACKER_2;
	}
	else if(nMotorPos == 4)
	{
		m_n_axis = M_LDM_STACKER_MOVE;
	}
	else
	{
		m_n_axis = M_WORK_BUFFER_1 + nMotorPos - 5;
	}
	
	Init_Button();

}

void CDialog_Manual_Module::OnBtnGoModulePos() 
{
	// TODO: Add your control notification handler code here
	int n_tray_y;
	int mn_FirstPicker_Y_Pos = 0;
	////////////////////// 20121107
	int	nRet;	
	int n_response;	
	CDialog_Message  msg_dlg;
	////////////////////// 
	
	n_tray_y = m_cmb_module_pos.GetCurSel();
	
	if (n_tray_y < 0)	
	{
		if (st_handler.cwnd_list != NULL)  // ����Ʈ �� ȭ�� ����
		{
			sprintf(st_msg.c_abnormal_msg,"[Module RBT] can not move.");
			st_handler.cwnd_list->PostMessage(WM_LIST_DATA, 0, ABNORMAL_MSG);  // ���� �Ϸ� ��� ��û
		}
		return;
	}
	
	OnSite_Controls_Enable(FALSE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
	
	if (st_handler.mn_menu_lock != TRUE)
		st_handler.mn_menu_lock = TRUE;
	// **************************************************************************
	
	OnSite_Step_Clear();				// ���� ���� ó�� ���� �ʱ�ȭ �Լ�
	// **************************************************************************
	// ���� �̵� ��ġ �����Ѵ�                                                   
	// **************************************************************************

	////////////////////// 20121107
	if(n_tray_y == 7 || n_tray_y == 8 || n_tray_y == 9 || n_tray_y == 10 ||
	   n_tray_y == 11 || n_tray_y == 12 || n_tray_y == 13 ||
	   n_tray_y == 14 || n_tray_y == 15 || n_tray_y == 16 || n_tray_y == 17 ||
	   n_tray_y == 18 || n_tray_y == 19 || n_tray_y == 20 || n_tray_y == 21 ||
	   n_tray_y == 22 || n_tray_y == 23 || n_tray_y == 24 || n_tray_y == 25 ||
	   n_tray_y == 26 || n_tray_y == 27 || n_tray_y == 28)
	{
	}
	else
	{
		nRet = COMI.Check_SingleMove(M_M_RBT_Z, st_motor[M_M_RBT_Z].md_pos[Z_LD_SAFETY_UP]);
		if (nRet != CTLBD_RET_GOOD)
		{
			st_msg.str_fallacy_msg = _T("Z���� Safety ��ġ�� �ƴմϴ�.");	
			if(st_handler.mn_language == LANGUAGE_ENGLISH)
			{
				st_msg.str_fallacy_msg = _T("Safety is not the position of the Z-axis");
			}
			
			n_response = msg_dlg.DoModal();
			OnSite_Controls_Enable(TRUE);  // ��� ��Ʈ�� ȭ�� ��� ���� �Լ�
			st_handler.mn_menu_lock = FALSE;
			return;
		}
		else
		{
		}
	}
	//////////////////////
	
	mn_cmd_no = MOT_MOVE;					// ���� ���� ��ȣ ���� [���� �̵� ����]
//	mn_motor_no = M_M_RBT_Y;
	if(n_tray_y == 0 || n_tray_y == 1 || n_tray_y == 2 || n_tray_y == 3 ||
	   n_tray_y == 4 || n_tray_y == 5 || n_tray_y == 6) mn_motor_no = M_M_RBT_Y;

	if(n_tray_y == 7 || n_tray_y == 8 || n_tray_y == 9 || n_tray_y == 10 ||
	   n_tray_y == 11 || n_tray_y == 12 || n_tray_y == 13) mn_motor_no = M_M_RBT_Z;

	if(n_tray_y == 14 || n_tray_y == 15 || n_tray_y == 16 || n_tray_y == 17 ||
		n_tray_y == 18 || n_tray_y == 19) mn_motor_no = M_LDM_STACKER_1;
	
	if(n_tray_y == 20 || n_tray_y == 21 || n_tray_y == 22 || n_tray_y == 23 ||
		n_tray_y == 24 || n_tray_y == 25) mn_motor_no = M_LDM_STACKER_2;
	
	if(n_tray_y == 26 || n_tray_y == 27 || n_tray_y == 28) mn_motor_no = M_LDM_STACKER_MOVE;


	if(n_tray_y == 0) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[0];
	}
	else if(n_tray_y == 1)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[1];	
	}
	else if(n_tray_y == 2)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[2];	
	}
	else if(n_tray_y == 3)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[3];	
	}
	else if(n_tray_y == 4)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[4];	
	}
	else if(n_tray_y == 5) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[5];
	}
	else if(n_tray_y == 6) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[6];
	}
	else if(n_tray_y == 7) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[0];
	}
	else if(n_tray_y == 8)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[1];	
	}
	else if(n_tray_y == 9)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[2];	
	}
	else if(n_tray_y == 10)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[3];	
	}
	else if(n_tray_y == 11)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[4];	
	}
	else if(n_tray_y == 12) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[5];
	}
	else if(n_tray_y == 13) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[6];
	}
	else if(n_tray_y == 14) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[0];
	}
	else if(n_tray_y == 15)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[1];	
	}
	else if(n_tray_y == 16)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[2];	
	}
	else if(n_tray_y == 17)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[3];	
	}
	else if(n_tray_y == 18)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[4];	
	}
	else if(n_tray_y == 19) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[5];
	}
	else if(n_tray_y == 20) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[0];
	}
	else if(n_tray_y == 21)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[1];	
	}
	else if(n_tray_y == 22)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[2];	
	}
	else if(n_tray_y == 23)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[3];	
	}
	else if(n_tray_y == 24)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[4];	
	}
	else if(n_tray_y == 25) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[5];
	}
	else if(n_tray_y == 26) 
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[0];
	}
	else if(n_tray_y == 27)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[1];	
	}
	else if(n_tray_y == 28)
	{
		md_mot_start_pos = st_motor[mn_motor_no].md_pos[2];	
	}

	SetTimer(TMR_MODULEMOT_CMD, 10, NULL);		// ���� ���� ���� Ÿ�̸�
	// **************************************************************************		
		
}


BOOL CDialog_Manual_Module::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_p_font != NULL)
	{
		delete m_p_font;
		m_p_font = NULL;
	}
	if(m_load_combo_font != NULL)
	{
		delete m_load_combo_font;
		m_load_combo_font = NULL;
	}
	if(m_motor_font != NULL)
	{
		delete m_motor_font;
		m_motor_font = NULL;
	}
	
	return CDialog::DestroyWindow();
}
